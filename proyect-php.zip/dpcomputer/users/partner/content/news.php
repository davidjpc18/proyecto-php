<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de noticias - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/users/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/users/css/partner/news.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">

</head>
<body>

    <!--Session status-->
    <?php include('../../config/sessionStatus.php'); ?>
    
    <!--Header-->
    <?php include('../../template/header/headerPartner.php') ?>

    <!--Connection to Data Base-->
    <?php include('../../config/connectionDB.php') ?>

    <!--Views News-->
    <?php include('../../config/news/viewsNews.php'); ?>

    <div class="new__container">
        
        <h2 class="new__title">Listado de noticias<span class="dot">:</span></h2>

        <!--Add User button-->
        <a href="../../config/news/addFormNew.php" class="btn__add"><i class="far fa-newspaper"></i> Nueva Noticia</a>

        <div class="new__table--container">
            <table class="new__table">
                <tr class="table__row--title">
                    <th>ID</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Nombre de la imagen</th>
                    <th>Administración</th>
                </tr>
                <?php 
                    if ($result > 0) {
                        while ($new = mysqli_fetch_array($consult)) {
                ?>
                <tr class="table__row">
                    <td id="id"><?php echo $new['idNew']; ?></td>
                    <td id="title"><?php echo $new['title']; ?></td>
                    <td id="description"><?php echo substr($new['description'], 0, 250)."..."; ?></td>
                    <td id="imageName"><?php echo $new['imageName']; ?></td>
                    <td id="administration">
                        <form action="../../config/news/modNew.php" method="post">
                            <input type="text" name="idNew" id="idNew" value="<?php echo $new['idNew'];?>" hidden>
                            <button type="submit" id="btn__select" name="action" value="select">Seleccionar</button>
                            <button type="submit" id="btn__drop" name="action" value="drop">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php
                        }
                    }
                ?>
            </table>
        </div>

    </div>

</body>
</html>    