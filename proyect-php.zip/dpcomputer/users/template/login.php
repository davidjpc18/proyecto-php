<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - DPComputer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/template/login.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">

    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!--Database connecttion-->
    <?php include("../config/connectionDB.php") ?>
    
    <!--Login-->
    <div class="login__container">
        <div class="login">

            <!--Form login-->
            <form action="../config/valLogin.php" id="form" method="post">
                <h3 class="form__title--main">Iniciar sesión</h3>
                <div class="form__inputs">
                    <label class="form__title">Usuario<span class="dot">:</span></label>
                    <input type="text" name="email" id="email" placeholder="Introduce tu correo electrónico." autocomplete="on">
                </div>
                <div class="form__inputs">
                    <label class="form__title">Contraseña<span class="dot">:</span></label>
                    <input type="password" name="password" id="password" placeholder="Introduce tu contraseña." autocomplete="on">
                </div>
                <div class="form__input-boton">
                    <button type="submit" id="boton__enviar">Login</button>
                </div>
            </form>

            <!--Welcome-->
            <div class="welcome">
                <h3 class="welcome__title">Bienvenido</h3>
                <div class="welcome__copy--container">
                    <p class="welcome__copy">¿No tienes cuenta? <a href="/dpcomputer/users/template/singup.php" class="welcome__singup">Registrate</a></p>
                    <p class="welcome__copy"><i class="fas fa-angle-double-left"></i> <a href="../../index.php" class="welcome__back">Volver</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>