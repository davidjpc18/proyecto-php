<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crea tu cuenta - DPComputer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/users/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/users/css/template/singup.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">

    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Database connecttion-->
    <?php include("../config/connectionDB.php") ?>
    
    <!--Sing Up-->
    <div class="singup">
        <h3 class="form__title--main">Crea tu cuenta</h3>
        <form action="../config/addUser.php" method="post" id="form">

            <!--DNI-->
            <div class="form__inputs">
                <label class="form__title">DNI<span class="dot">:</span></label>
                <input type="text" name="dni" id="dni" placeholder="00000000A">
            </div>

            <!--Name-->
            <div class="form__inputs">
                <label class="form__title">Nombres<span class="dot">:</span></label>
                <input type="text" name="name" id="name" placeholder="José" autocomplete="on">        
            </div>

            <!--Firth surname-->
            <div class="form__inputs">
                <label class="form__title">Primer apellido<span class="dot">:</span></label>
                <input type="text" name="firthSurname" id="firthSurname" placeholder="Pérez" autocomplete="on">
            </div>

            <!--Second surname-->
            <div class="form__inputs">
                <label class="form__title">Segundo apellido<span class="dot">:</span></label>
                <input type="text" name="secondSurname" id="secondSurname" placeholder="Pérez" autocomplete="on">
            </div>

            <!--Phone-->
            <div class="form__inputs">
                <label class="form__title">Teléfono<span class="dot">:</span></label>
                <input type="number" name="phone" id="phone" maxlength="9" placeholder="666666666" autocomplete="on">
            </div>

            <!--Email-->
            <div class="form__inputs">
                <label class="form__title">Correo electrónico<span class="dot">:</span></label>
                <input type="text" name="email" id="email" placeholder="jose.perez@gmail.com" autocomplete="on">
            </div>

            <!--Password-->
            <div class="form__inputs">
                <label class="form__title">Contraseña<span class="dot">:</span></label>
                <input type="password" name="password" id="password" placeholder="Introduce 8 caracteres como mínimo.">
            </div>
            <div class="form__inputs">
                <label class="form__title">Confirmar contraseña<span class="dot">:</span></label>
                <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Vuelva a escribir su contraseña.">
            </div>

            <!--Date of birth-->
            <div class="form__inputs">
                <label class="form__title">Fecha de Nacimiento<span class="dot">:</span></label>
                <input type="date" name="birth" id="birth">
            </div>

            <div class="form__container--inputs">

                <!--Politic-->
                <div class="form__input--politic">
                    <input type="checkbox" name="politic" id="politic">
                    <a href="/public/politica.html" class="form__checkbox--link">Acepto los Terminos y Condiciones</a>
                </div>

                <!--Send boton-->
                <div class="form__input--boton">
                    <button type="button" id="send__btn" onclick="validationForm()">Enviar</button>
                </div>
            </div>

            <!--Message area-->
            <div id="form__msg" class="form__msg"></div>
        </form>
    </div>

    <!--JavaScript-->
    <script src="../js/template/singup.js"></script>
</body>
</html>