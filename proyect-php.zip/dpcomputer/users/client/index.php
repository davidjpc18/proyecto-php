<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de cliente - DPComputer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/client/index.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">

</head>
<body>
    
    <!--Session status-->
    <?php include('../config/sessionStatus.php'); ?>

    <!--Header-->
    <?php include('../template/header/headerClient.php'); ?>

    <!--View User name-->
    <?php

        //Connection to Database.
        include('../config/connectionDB.php'); 

        $dni = $_SESSION['user'];

        $consult = mysqli_query($conn, "SELECT * FROM users WHERE dni = '$dni'");

        $result = mysqli_num_rows($consult);

        if ($result > 0) {
            $user = mysqli_fetch_assoc($consult);
        }
    
    ?>

    <div class="client__container">

        <h2 class="client__title"><?php echo "<span class='dot'>¡</span>Hola, ".$user['name']." ".$user['firthSurname']." ".$user['secondSurname']."<span class='dot'>!</span>"; ?></h2>

        <!--Button area-->
        <div class="btn__container">
            <a href="./content/account.php" class="btn">
                <span class="btn__icon"><i class="fas fa-user-alt"></i></span>
                <span class="btn__title">Mi cuenta</span>        
            </a>
            <a href="./content/meetings.php" class="btn">
                <span class="btn__icon"><i class="fas fa-calendar-alt"></i></span>
                <span class="btn__title">Citas</span>
            </a>
        </div>
    </div>
    
</body>
</html>