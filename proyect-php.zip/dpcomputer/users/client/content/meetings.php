<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Citas personales - DPComputer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/client/meetings.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">

</head>
<body>
    <!--Session status-->
    <?php include('../../config/sessionStatus.php'); ?>

    <!--Header-->
    <?php include('../../template/header/headerClient.php'); ?>

    <!--Connection to Database-->
    <?php include('../../config/connectionDB.php'); ?>

    <!--Views personal meetigns-->
    <?php include('../../config/meetings/viewsMeeting.php') ?>

    <section class="meeting__container">
        <h2 class="meeting__title">CITAS PERSONALES<span class="dot">:</span></h2>
        <div class="card__container">
            <?php
                if ($result > 0) {
                    while ($meeting = mysqli_fetch_assoc($consult)) {
            ?>
            <div class="card">
                <h3 class="card__title">Cita<span class="dot">:</span></h3>
                <p class="card__info"><b>DNI<span class="dot">:</span></b> <?php echo $meeting['dni']; ?></p>
                <p class="card__info"><b>Nombre<span class="dot">:</span></b> <?php echo $meeting['name']; ?></p>
                <p class="card__info"><b>Apellido<span class="dot">:</span></b> <?php echo $meeting['firthSurname']; ?></p>
                <p class="card__info"><b>Correo electrónico<span class="dot">:</span></b> <?php echo $meeting['email']; ?></p>
                <p class="card__info"><b>Teléfono<span class="dot">:</span></b> <?php echo $meeting['phone']; ?></p>
                <p class="card__info"><b>Fecha y hora<span class="dot">:</span></b> <?php
                    $dateMeeting = new DateTime($meeting['dateMeeting']);                
                    echo $dateMeeting -> format('d/m/Y').' - '.$meeting['hourMeeting']; ?></p>
                <form action="../../config/meetings/modMeeting.php" method="post" id="form">
                    <input type="text" name="idMeeting" id="idMeeting" value="<?php echo $meeting['idMeeting']; ?>" hidden>
                    <input type="text" name="dateMeeting" id="dateMeeting" value="<?php echo $meeting['dateMeeting']; ?>" hidden>
                    <button type="submit" name="action" id="btn__change" value="change">Modificar</button>
                    <button type="submit" name="action" id="btn__drop" value="drop">Anular</button>
                </form>

            </div>
            <?php
                    }
                }
            ?>
        </div>

    </section>

</body>
</html>