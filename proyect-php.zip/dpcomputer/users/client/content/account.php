<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de cliente - DPComputer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/client/account.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">

</head>
<body>
    
    <!--Session status-->
    <?php include('../../config/sessionStatus.php'); ?>

    <!--Header-->
    <?php include('../../template/header/headerClient.php'); ?>

    <!--Connection to Database-->
    <?php include('../../config/connectionDB.php'); ?>

    <!--Views personal data-->
    <?php include('../../config/account/viewsAccount.php'); ?>

    <!--Form area-->
    <section class="account__container">
        <h2 class="account__title">DATOS PERSONALES<span class="dot">:</span></h2>
        <div class="form__container">

            <!--Form User-->
            <form method="POST" action="../../config/account/changeEmail.php" id="form__user">
                <h3 class="form__user--title"><i class="fas fa-shield-alt form__user--title--icon"></i> Datos de usuario</h3>
                <div class="account__inputs">
                    <label class="account__input--title">Email<span class="dot">:</span></label>
                    <input type="text" class="account__input" id="email" name="email" value="<?php echo $row['email'] ?>">                
                </div>
                <div class="account__inputs--btn">
                    <button type="button" name="btnUser" id="btn__user" onclick="validationEmail()">Guardar</button>
                    <a href="../../config/account/changePassword.php" id="btnPassword"><i class="fas fa-key"></i> Cambiar contraseña</a>
                </div>
                <div id="form__user--msg" class="form__msg"></div>
            </form>

            <!--Form data-->
            <form method="POST" action="../../config/account/changePhone.php" id="form__data">
                <h3 class="form__data--title"><i class="fas fa-address-card form__data--title--icon"></i> Datos personales</h3>
                <div class="account__inputs">
                    <label class="account__input--title">Nombre<span class="dot">:</span></label>
                    <input type="text" class="account__input" name="name" value="<?php echo $row['name']; ?>" disabled>
                </div>
                <div class="account__inputs">
                    <label class="account__input--title">Primer apellido<span class="dot">:</span></label>
                    <input type="text" class="account__input" name="firthSurname" value="<?php echo $row['firthSurname']; ?>" disabled>
                </div>
                <div class="account__inputs">
                    <label class="account__input--title">Segundo apellido<span class="dot">:</span></label>
                    <input type="text" class="account__input" name="secondSurname" value="<?php echo $row['secondSurname']; ?>" disabled>
                </div>
                <div class="account__inputs">
                    <label class="account__input--title">DNI<span class="dot">:</span></label>
                    <input type="text" class="account__input" name="dni" value="<?php echo $row['dni']; ?>" disabled>
                </div>
                <div class="account__inputs">
                    <label class="account__input--title">Fecha de nacimiento<span class="dot">:</span></label>
                    <input type="date" class="account__input" name="birth" value="<?php echo $row['birth']; ?>" disabled>
                </div>
                <div class="account__inputs">
                    <label class="account__input--title">Teléfono<span class="dot">:</span></label>
                    <input type="text" class="account__input" id="phone" name="phone" value="<?php echo $row['phone']; ?>">
                </div>
                <div class="account__inputs-btn">
                    <button type="button" name="btnData" id="btn__data" onclick="validationPhone()">Guardar</button>
                </div>
                <div id="form__data--msg" class="form__msg"></div>
            </form>
        </div>
    </section>

    <!--JavaScript-->
    <script src="../../js/client/account/valForm.js"></script>
</body>
</html>