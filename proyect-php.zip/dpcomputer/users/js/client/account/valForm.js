// Validation Form user

const formEmail = document.getElementById('form__user');
const formPhone = document.getElementById('form__data');
const formPassword = document.getElementById('form__password');


var validation = "";

var msg = "";

// Validation Email
function validationEmail() {

    const email = document.getElementById('email').value;

    //Expresión regular para que compruebe que es correcta la estructura de un email: "info@info.com"
    const valEmail = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;

    if (email == "") {
        validation = false;
        msg = msg + '<li>El campo "Email" no puede estar vacío.</li>';
    }if (!valEmail.test(email)){
        validation = false;
        msg = msg + '<li>El email debe contener esta estructura "ejemplo@ejemplo.com".</li>';
    }else {
        validation = true;
    }

    //Error message container
    const msgContainer = document.getElementById('form__user--msg');

    //Creation error message
    var msgError = '<span><i class="fas fa-exclamation-triangle"></i> Error:</span>\n' + '<ul>' + msg + '</ul>';

    if (validation == false) {
        msgContainer.classList.add('form__msg--error');
        msgContainer.innerHTML = msgError;
    }if (validation == true) {
        formEmail.submit();
    }
}

//Validation Password
function validationPassword() {

    const oldPassword = document.getElementById('oldPassword').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    //Expresion regular para comprobar una contraseña
    const valPassword =  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&#.$($)$-$_])[A-Za-z\d$@$!%*?&#.$($)$-$_]{8,20}$/;
    
    if (oldPassword == "") {
        validation = false;
        msg = msg + '<li>El campo "Contraseña antigua" no puede estar vacíos.</li>'
    }if (password == "") {
        validation = false;
        msg = msg + '<li>El campo "Contraseña" no puede estar vacíos.</li>'
    }if (confirmPassword == ""){
        validation = false;
        msg = msg + '<li>El campo "Confirmar contraseña" no puede estar vacío."</li>'
    }if (oldPassword == password) {
        validation = false;
        msg = msg + '<li>No puede ser igual la "Contraseña antigua" de la "nueva Contraseña"</li>'
    }if (password !== confirmPassword) {
        validation = false;
        msg = msg + '<li>Los campos "Contraseña" y "Confirmar contraseña" deben coincidir.</li>'
    }if (!valPassword.test(password)) {
        validation = false;
        msg = msg + '<li>Los campos "Contraseña" y "Confirmar contraseña" deben contener mayúsculas, minúsculas, números, caracteres especiales y deben contener entre 8 a 20 caracteres.</li>'
    }else {
        validation = true;
    }

    //Error message container
    const msgContainer = document.getElementById('form__user--msg');

    //Creation error message
    var msgError = '<span><i class="fas fa-exclamation-triangle"></i> Error:</span>\n' + '<ul>' + msg + '</ul>';

    if (validation == false) {
        msgContainer.classList.add('form__msg--error');
        msgContainer.innerHTML = msgError;
    }if (validation == true) {
        formPassword.submit();
    }
}

//Validation Phone
function validationPhone() {

    const phone = document.getElementById('phone').value;

    //Expresión regular para comprobar que es un número de teléfono correcto.
    const valPhone = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{3})$/;

    if (phone == ""){
        validation = false;
        msg = msg + '<li>El campo "Teléfono" no puede estar vacío.</li>';
    }if (isNaN(phone)){
        validation = false;
        msg = msg + '<li>El campo "Teléfono" no puede contener letras.</li>';
    }if (!valPhone.test(phone)){
        validation = false;
        msg = msg + '<li>El campo "Teléfono" debe tener 9 dígitos.</li>';
    }else {
        validation = true;
    }

    //Error message container
    const msgContainer = document.getElementById('form__data--msg');

    //Creation error message
    var msgError = '<span><i class="fas fa-exclamation-triangle"></i> Error:</span>\n' + '<ul>' + msg + '</ul>';

    if (validation == false) {
        msgContainer.classList.add('form__msg--error');
        msgContainer.innerHTML = msgError;
    }if (validation == true) {
        formPhone.submit();
    }
}