//Validation Form

const form = document.getElementById('form');

var validation = "";

var msg = "";

function validationForm() {

    validationDNI();
    validationName();
    validationSurnames();
    validationBirth();
    validationEmail();
    validationPhone();
    validationPassword();
    validationPolitic();   

    //Error message container
    const msgContainer = document.getElementById('form__msg');

    //Creation error message
    var msgError = '<span><i class="fas fa-exclamation-triangle"></i> Error:</span>\n' + '<ul>' + msg + '</ul>';

    if (validation == false) {
        msgContainer.classList.add('form__msg--error');
        msgContainer.innerHTML = msgError;
    }else {
        form.submit();
    }
}

//Validation DNI
function validationDNI() {

    var dni = document.getElementById('dni').value;

    //Validation
    valDNI = /^\d{8}[a-zA-Z]$/;
    letterDNI = dni.substring(8,9).toUpperCase();
    numberDNI = parseInt(dni.substring(0,8));
    const letters = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
    var correctLetter = letters[numberDNI % 23];

    if (dni == "") {
        validation = false;
        msg = msg + '<li>El campo "DNI" no puede estar vacío</li>';
    }if (!valDNI.test(dni)) {
        validation = false;
        msg = msg + '<li>El campo "DNI" debe contener 8 números y una letra.</li>'; 
    }if (letterDNI !== correctLetter) {
        validation = false;
        msg = msg + '<li>La letra del campo "DNI" no es correcta.</li>';
    }else {
        validation = true;
    }

}

//Validation name
function validationName() {

    const name = document.getElementById('name').value;

    //Validation
    const valName = /^[a-zA-ZÀ-ÿ\s]{3,35}$/;

    if (name == ""){
        validation = false;
        msg = msg + '<li>El campo "Nombre" no puede estar vacío.</li>';
    }if (!valName.test(name)){
        validation = false;
        msg = msg + '<li>El campo "Nombre" debe tener más de 3 caracteres y puede contener mayúsculas, minúsculas y acentos.</li>';
    }else {
        validation = true;
    }

}

//Validation Surnames
function validationSurnames() {

    const firthSurname = document.getElementById('firthSurname').value;
    const secondSurname = document.getElementById('secondSurname').value;

    //Validation
    const valSurnames = /^[a-zA-ZÀ-ÿ\s]{3,35}$/;

    if (firthSurname == "") {
        validation = false;
        msg = msg + '<li>El campo "Primer apellido" no puede estar vacío.</li>'
    }if (secondSurname == "") {
        validation = false;
        msg = msg + '<li>El campo "Segundo apellido" no puede estar vacío.</li>'
    }if (!valSurnames.test(firthSurname)) {
        validation = false;
        msg = msg + '<li>El campo "Primer apellido" debe tener más de 3 caracteres y puede contener mayúsculas, minúsculas y acentos.</li>';
    }if (!valSurnames.test(secondSurname)) {
        validation = false;
        msg = msg + '<li>El campo "Segundo apellido" debe tener más de 3 caracteres y puede contener mayúsculas, minúsculas y acentos.</li>';
    }else {
        validation = true;
    }
}

//Validation Birth
function validationBirth() {
    const birth = document.getElementById('birth').value;

    //Validation
    var dateBirth = new Date(birth);
    var today = new Date();
    var age = today.getFullYear() - dateBirth.getFullYear(); 

    if (dateBirth == "Invalid Date") {
        validation = false;
        msg = msg + '<li>El campo "Fecha de nacimiento" no puede estar vacío o debe poner una fecha válida.</li>';
    }if (dateBirth >= today) {
        validation = false;
        msg = msg + '<li>El campo "Fecha de nacimiento" no puede ser igual o mayor a la fecha de hoy</li>';
    }if (age <= 18) {
        validation = false;
        msg = msg + '<li>El usuario debe ser mayor de 18 años.</li>'
    }else {
        validation = true;
    }

}

//Validation Email
function validationEmail() {

    const email = document.getElementById('email').value;

    //Validation
    valEmail = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;

    if (email == ""){
        validation = false;
        msg = msg + '<li>El campo "Email" no puede estar vacío.</li>';
    }if (!valEmail.test(email)){
        validation = false;
        msg = msg + '<li>El campo "Email" debe contener esta estructura "ejemplo@ejemplo.com".</li>';
    }else {
        validation = true;
    }

}

//Validation Phone
function validationPhone() {

    const phone = document.getElementById('phone').value;

    //Validation
    valPhone = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{3})$/;

    if (phone == ""){
        validation = false;
        msg = msg + '<li>El campo "Teléfono" no puede estar vacío.</li>';
    }if (isNaN(phone)){
        validation = false;
        msg = msg + '<li>El campo "Teléfono" no puede contener letras.</li>';
    }if (!valPhone.test(phone)){
        validation = false;
        msg = msg + '<li>El campo "Teléfono" debe tener 9 dígitos.</li>';
    }else {
        validation = true;
    }

}

function validationPassword() {

    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    //Validation
    const valPass =  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&#.$($)$-$_])[A-Za-z\d$@$!%*?&#.$($)$-$_]{8,20}$/;

    if (password == ""){
        validation = false;
        msg = msg + '<li>El campo "Contraseña" no puede estar vacío.</li>';        
    }if (confirmPassword == "") {
        validation = false;
        msg = msg + '<li>El campo "Confirmar contraseña" no puede estar vacío.</li>';
    }if (password !== confirmPassword) {
        validation = false;
        msg = msg + '<li>El campo "Contraseña" debe coincidir con "Confirmar contraseña"</li>';
    }if (!valPass.test(password)) {
        validation = false;
        msg = msg + '<li>El campo "Contraseña" debe contener mayúsculas, minúsculas, números, caracteres especiales y debe contener entre 8 a 20 caracteres.</li>'
    }

}

//Validation Politic
function validationPolitic() {

    const politic = document.getElementById('politic');

    //Validation
    if (politic.checked == false) {
        validation = false;
        msg = msg + '<li>El campo "Acepto los Terminos y Condiciones" debe estar seleccionado.</li>'
    }else {
        validation = true;
    }
}