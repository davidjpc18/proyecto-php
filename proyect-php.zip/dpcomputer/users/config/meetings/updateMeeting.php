<?php

    //Connection to Database
    include('../connectionDB.php');

    $meeting = $_POST['idMeeting'];
    $date = $_POST['dateMeeting'];
    $hour = $_POST['hourMeeting'];

    $consultMeeting = mysqli_query($conn, "SELECT * FROM meetings WHERE idMeeting = '$meeting'");

    if (mysqli_num_rows($consultMeeting) > 0) {
        $row = mysqli_fetch_assoc($consultMeeting);
    }

    $cmpDate = strcmp($date, $row['dateMeeting']);
    $cmpHour = strcmp($hour, $row['hourMeeting']);

    if ($cmpDate == 0 && $cmpHour == 0){
        echo '<script>
                window.location = "../../client/content/meetings.php";
                alert("No pueden coincidir la misma fecha y hora");
            </script>';
    }else {
        $sql = mysqli_query($conn, "UPDATE meetings SET dateMeeting = '$date', hourMeeting = '$hour' WHERE idMeeting = '$meeting'");
        echo '<script>
                window.location = "../../client/content/meetings.php";
                alert("Se han modificado la cita satisfactoriamente.");
            </script>';
    }
?>