<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar cita - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/client/modMeeting.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">

</head>
<body>

    <!--Connection to Database-->
    <?php include('../connectionDB.php');?>

    <?php
    
        $meeting = $_POST['idMeeting'];

        $action = $_POST['action'];

        if ($action == 'drop') {
            $sql = mysqli_query($conn, "DELETE FROM meetings WHERE idMeeting = '$meeting'");
            echo '<script>
                window.location = "../../client/content/meetings.php";
                alert("La cita se ha borrado correctamente");
            </script>';
        }if ($action == 'change') {

            $dateMeeting = strtotime($_POST['dateMeeting']);
            $dateToday = time();
            $rest = ($dateMeeting - $dateToday)/86400;
            $rest = ceil($rest);

            if ($rest <= 3) {
                echo '<script>
                        window.location = "../../client/content/meetings.php";
                        alert("No se puede modificar la cita. Por favor, anulela y escoja otra cita.");
                    </script>';
            }else {
                $consult = mysqli_query($conn, "SELECT dateMeeting, hourMeeting FROM meetings WHERE idMeeting = '$meeting'");

                if (mysqli_num_rows($consult) > 0) {
                    $row = mysqli_fetch_assoc($consult);
                }
            }

        }
    
    ?>

    <div class="form__container">
        <form action="updateMeeting.php" method="post" id="form">
        <h3 class="form__title">Modificar cita<span class="dot">:</span></h3>
            <div class="form__inputs">
                <label class="input__title">Fecha<span class="dot">:</span></label>
                <input type="date" name="dateMeeting" id="dateMeeting" value="<?php echo $row['dateMeeting'];?>">
            </div>
            <div class="form__inputs">
                <label class="input__title">Hora<span class="dot">:</span></label>
                <input type="text" name="hourMeeting" id="hourMeeting" value="<?php echo $row['hourMeeting'];?>">
            </div>
            <div class="form__inputs--btn">
                <input type="text" name="idMeeting" value="<?php echo $meeting; ?>" hidden>
                <button type="button" id="btn__mod" onclick="validationForm()">Modificar</button>
                <button type="reset" id="btn__reset">Resetear</button>
            </div>
            <div id="form__msg" class="form__msg"></div>
        </form>
    </div>
    
    <!--JavaScript-->
    <script src="../../js/client/meetings/modMeeting.js"></script>

</body>
</html>