<?php

    $dni = $_SESSION['user'];

    $consult = mysqli_query($conn, "SELECT m.idMeeting, m.dateMeeting, m.hourMeeting, m.dni, u.dni, u.name, u.firthSurname, u.email, u.phone FROM meetings m, users u WHERE m.dni = '$dni' AND m.dni = u.dni");

    $result = mysqli_num_rows($consult);
    
?>