<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Portfolio - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/users/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/users/css/partner/formNew.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!--Connection to Data Base-->
    <?php include('../connectionDB.php'); ?>

    <?php
    
    $new = $_POST['idNew'];

    $action = $_POST['action'];

    $consult = mysqli_query($conn, "SELECT * FROM news WHERE idNew = '$new'");

    $row = mysqli_fetch_assoc($consult);

    if ($action == "drop") {
        $picture = $row['imageName'];
        if (isset($picture)){
            if (file_exists("../../../img/new/".$picture)) {
                unlink("../../../img/new/".$picture);
            }
        }
        $sql = mysqli_query($conn, "DELETE FROM news WHERE idNew = '$new'");
        echo '<script>
                window.location = "../../partner/content/news.php";
                alert("La noticia se ha borrado correctamente");
            </script>';
    }
    
    ?>

    <!--Administration Portfolio-->
    <div class="form__container">
        <form action="updateNew.php" method="POST" id="admin">
            <h3 class="admin__title">Modificar Noticia<span class="dot">:</span></h3>
            <input type="text" name="idNew" id="idNew" value="<?php echo $row['idNew'] ?>" hidden>
            <div class="form__inputs">
                <label class="input__title">Título<span class="dot">:</span></label>
                <textarea name="title" id="title"><?php echo $row['title']; ?></textarea>
            </div>
            <div class="form__inputs">
                <label class="input__title">Descripción<span class="dot">:</span></label>
                <textarea name="description" id="description"><?php echo $row['description']; ?></textarea>
            </div>
            <div class="form__inputs--btn">
                <button type="button" id="btn__image" onclick="viewFormImage()"><i class="fas fa-images"></i> Cambiar imagen</button>
                <button type="submit" id="btn__mod">Modificar</button>
                <button type="reset" id="btn__reset">Resetear</button>
            </div>
        </form>
        <div id="image__container" class="image__container">
            <form action="imageNew.php" method="POST" id="form__image" enctype="multipart/form-data">
                <input type="hidden" name="idNew" value="<?php echo $row['idNew']; ?>">    
                <h3 class="admin__title">Cambiar Imagen<span class="dot">:</span></h3>
                <div class="form__inputs--image">
                    <p class="input__image"><label class="input__title--image">Imagen<span class="dot">:</span></label>
                    <?php echo $row['imageName'];?>
                    <input type="file" name="image" id="image" accept="image/*" value="<?php echo $row['imageName'];?>"></p>
                </div>
                <div class="form__inputs--btn">
                    <button type="submit" id="btn__mod--image">Cambiar Imagen</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function viewFormImage() {
            const container = document.getElementById('image__container');
            container.classList.toggle('image__container--view');
        }
    </script>

</body>
</html>