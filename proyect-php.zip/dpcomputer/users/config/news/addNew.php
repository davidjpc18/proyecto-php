<?php

    //Connection to Data Base
    include('../connectionDB.php');

    $title = $_POST['title'];
    $description = $_POST['description'];

    $image = $_FILES['image'];
    $name = $_FILES['image']['name'];
    $tmpImage = $image['tmp_name'];
    $date = new DateTime();
    $imageName = $date->getTimestamp()."_".$name;
    $imageLink = "/dpcomputer/img/new/".$imageName;
    
    if ($tmpImage !== "") {
        move_uploaded_file($tmpImage, "../../../img/new/".$imageName);
    }

    $validation = "";

    if ($title == "") {
        $validation = false;
    }if ($description == "") {
        $validation = false;
    }if ($image == "") {
        $validation = false;
    }else {
        $validation = true;
    }

    if ($validation == false) {
        echo '<script>
                window.location = "addFormNew.php";
                alert("Todos los campos deben estar rellenos");
            </script>';
    }else {
        $sql = mysqli_query($conn, "INSERT INTO news (title, description, imageName, imageLink) VALUES ('$title', '$description', '$imageName', '$imageLink')");
        echo '<script>
                window.location = "../../partner/content/news.php";
                alert("Se ha creado la noticia correctamente.");
            </script>';
    }

?>