<?php

    session_start();

    if(!isset($_SESSION['user'])) {
        echo '<script>
            alert("Por favor, es necesario iniciar sesión.");
            window.location = "/dpcomputer/users/template/login.php";
        </script>';
        session_destroy();
        die();
    }


?>