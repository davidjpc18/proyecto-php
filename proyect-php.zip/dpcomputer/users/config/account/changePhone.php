<?php

    include('../connectionDB.php');

    include('../sessionStatus.php');

    $dni = $_SESSION['user'];

    $consult = mysqli_query($conn, "SELECT phone, role FROM users WHERE dni = '$dni'");

    if (mysqli_num_rows($consult) > 0) {
        $row = mysqli_fetch_assoc($consult);
    }

    $role = $row['role'];

    //Validation change Phone

    $phone = $row['phone'];
    $changePhone = $_POST['phone'];

    if ($phone !== $changePhone) {
        if ($role == 'client') {
            $sql = mysqli_query($conn, "UPDATE users SET phone = '$changePhone' WHERE dni = '$dni'");
            echo '<script>
                    window.location = "../../client/content/account.php";
                    alert("El número de Teléfono ha sido modificado.");
                </script>';
        }else {
            $sql = mysqli_query($conn, "UPDATE users SET phone = '$changePhone' WHERE dni = '$dni'");
            echo '<script>
                    window.location = "../../partner/content/account.php";
                    alert("El número de Teléfono ha sido modificado.");
                </script>';
        }
        
    }else {
        if ($role == 'client') {
            echo '<script>
                    window.location = "../../client/content/account.php";
                    alert("El número de Teléfono no ha sido modificado.");
                </script>';
        }else {
            echo '<script>
                    window.location = "../../partner/content/account.php";
                    alert("El número de Teléfono no ha sido modificado.");
                </script>';
        }
    }
    
?>