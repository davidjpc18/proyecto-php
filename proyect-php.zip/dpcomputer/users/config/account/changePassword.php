<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de cliente - DPComputer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="../../css/main.css">
    <link rel="stylesheet" href="../../css/client/account.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">

</head>
<body>
    
    <!--Session status-->
    <?php include('../../config/sessionStatus.php'); ?>

    <!--Form area-->
    <div class="form__container">

        <form method="POST" action="password.php" id="form__password">
            <h3 class="form__user--title"><span class="dot"><i class="fas fa-key"></i></span> Cambiar contraseña</h3>
            <div class="account__inputs">
                <label class="account__input--title">Contraseña antigua<span class="dot">:</span></label>
                <input type="password" class="account__input" id="oldPassword" name="oldPassword">
            </div>
            <div class="account__inputs">
                <label class="account__input--title">Contraseña<span class="dot">:</span></label>
                <input type="password" class="account__input" id="password" name="password">
            </div>
            <div class="account__inputs">
                <label class="account__input--title">Confirmar contraseña<span class="dot">:</span></label>
                <input type="password" class="account__input" id="confirmPassword">
            </div>
            <div class="account__inputs--btn">
                <button type="button" name="btnUser" id="btn__user" onclick="validationPassword()">Guardar</button>
            </div>
            <div id="form__user--msg" class="form__msg"></div>
        </form>
        
    </div>

    <!--JavaScript-->
    <script src="../../js/client/account/valForm.js"></script>

</body>
</html>