<?php
    
    //Session status
    include('../../config/sessionStatus.php');

    //Connection to Database
    include('../../config/connectionDB.php');
    
    
    $dni = $_SESSION['user'];

        $consult = mysqli_query($conn, "SELECT role, password FROM users WHERE dni = '$dni'");

        if (mysqli_num_rows($consult) > 0) {
            $row = mysqli_fetch_assoc($consult);
        }

        $role = $row['role'];

        $password = $row['password'];
        $oldPassword = hash('SHA256', $_POST['oldPassword']);
        $changePassword = hash('SHA256', $_POST['password']);

        if ($password == $oldPassword) {
            if ($password !== $changePassword) {
                $sql = mysqli_query($conn, "UPDATE users SET password = '$changePassword' WHERE dni = '$dni'");
                if ($role == 'client') {
                    echo '<script>
                            window.location = "../../client/content/account.php";
                            alert("La Contraseña ha sido modificada");
                        </script>';
                }else {
                    echo '<script>
                            window.location = "../../partner/content/account.php";
                            alert("La Contraseña ha sido modificada");
                        </script>';
                }
            }else {
                if ($role == 'client') {
                    echo '<script>
                            window.location = "../../client/content/account.php";
                            alert("La Contraseña antigua y la nueva no pueden coincidir");
                        </script>';
                }else {
                    echo '<script>
                            window.location = "../../partner/content/account.php";
                            alert("La Contraseña antigua y la nueva no pueden coincidir");
                        </script>';
                }
            }
        }else {
            if ($role == 'client') {
                echo '<script>
                        window.location = "../../client/content/account.php";
                        alert("Debe introducir su contraseña correcta");
                    </script>';
            }else {
                echo '<script>
                        window.location = "../../partner/content/account.php";
                        alert("Debe introducir su contraseña correcta");
                    </script>';
            }
        }
    
    ?>