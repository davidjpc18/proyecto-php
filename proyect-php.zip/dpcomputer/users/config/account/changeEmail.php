<?php

    include('../connectionDB.php');

    include('../sessionStatus.php');

    $dni = $_SESSION['user'];

    $consult = mysqli_query($conn, "SELECT email, role FROM users WHERE dni = '$dni'");

    if (mysqli_num_rows($consult) > 0) {
        $row = mysqli_fetch_assoc($consult);
    }

    $role = $row['role'];

    //Validation change Email and Password

        //validation Email

        $email = $row['email'];
        $changeEmail = $_POST['email'];

        if ($email !== $changeEmail) {
            if ($role == 'client'){
                $sql = mysqli_query($conn, "UPDATE users SET email = '$changeEmail' WHERE dni = '$dni'");
                echo '<script>
                        window.location = "../../client/content/account.php";
                        alert("El email ha sido modificado")
                    </script>';
            }else {
                $sql = mysqli_query($conn, "UPDATE users SET email = '$changeEmail' WHERE dni = '$dni'");
                echo '<script>
                        window.location = "../../partner/content/account.php";
                        alert("El email ha sido modificado")
                    </script>';
            }
        }else {
            if ($role == 'client'){
                $sql = mysqli_query($conn, "UPDATE users SET email = '$changeEmail' WHERE dni = '$dni'");
                echo '<script>
                        window.location = "../../client/content/account.php";
                        alert("El email no ha sido modificado")
                    </script>';
            }else {
                $sql = mysqli_query($conn, "UPDATE users SET email = '$changeEmail' WHERE dni = '$dni'");
                echo '<script>
                        window.location = "../../partner/content/account.php";
                        alert("El email no ha sido modificado")
                    </script>';
            }
        }

?>