<?php

    $dni = $_SESSION['user'];

    $consult = mysqli_query($conn, "SELECT * FROM users WHERE dni = '$dni'");

    if ($consult) {
        $row = mysqli_fetch_assoc($consult);
    }

?>