<?php

    //Connection to Data Base.
    include('../config/connectionDB.php');

    $dni = $_POST['dni'];
    $name = $_POST['name'];
    $firthSurname = $_POST['firthSurname'];
    $secondSurname = $_POST['secondSurname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $birth = $_POST['birth'];
    $password = hash('SHA256', $_POST['password']);

    //Validation User
    $consultEmail = mysqli_query($conn, "SELECT email FROM users WHERE email = '$email'");
    $resultEmail = mysqli_num_rows($consultEmail);
    $consultDNI = mysqli_query($conn, "SELECT dni FROM users WHERE dni = '$dni'");
    $resultDNI = mysqli_num_rows($consultDNI);

    if ($resultEmail > 0) {
        echo "<script>
                    window.location = '../template/singup.php';
                    alert('¡Lo siento! Pero ese Correo electrónico ya está siendo utilizado');
                </script>";
    }if ($resultDNI) {
        echo "<script>
                    window.location = '../template/singup.php';
                    alert('¡Lo siento! Pero ese DNI ya está siendo utilizado');
                </script>";
    }else {
        $sql = mysqli_query($conn, "INSERT INTO users (dni, name, firthSurname, secondSurname, email, phone, birth, password) VALUES ('$dni', '$name', '$firthSurname', '$secondSurname', '$email', '$phone', '$birth', '$password')");

        if ($sql) {
            echo "<script>
                    window.location = '../template/login.php';
                    alert('Se ha creado tu cuenta satisfactoriamente');
                </script>";
        }else {
            echo "<script>
                    window.location = '../template/singup.php';
                    alert('Ups! Algo salió mal');
                </script>";
        }
    }


?>