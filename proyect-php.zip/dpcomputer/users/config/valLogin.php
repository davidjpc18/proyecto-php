<?php

    include('connectionDB.php');

    session_start();

    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = hash('SHA256', $password);

    $consult = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email' AND password = '$password'");

    $result = mysqli_num_rows($consult);

    if ($result > 0) {
        $row = mysqli_fetch_assoc($consult);
        $_SESSION['user'] = $row['dni'];
        if ($row['role'] == 'partner') {
            header("Location: ../partner/index.php");
            exit();
        }else {
            header("Location: ../client/index.php");
            exit();
        }
    }else {
        echo
            "<script>
                window.location = '../template/login.php';
                alert('Usuario o contraseña son erroneos, por favor verifique los datos introducidos');
            </script>";
        exit();
    }

?>