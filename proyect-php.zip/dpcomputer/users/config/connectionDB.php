<?php
    
    $servername = 'localhost';
    $database = 'dpcomputer';
    $username = 'davidjpc18';
    $password = 'P4ch3c0.16699';

    //Database connection
    $conn = mysqli_connect($servername, $username, $password, $database);

    if (!$conn) {
        echo 'Error en la conexión: ' . mysqli_connect_error();
    }

?>