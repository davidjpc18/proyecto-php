<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de citas - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/content/meetings/meetings.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">

</head>
<body>

    <!--Session status-->
    <?php include('../config/sessionStatus.php'); ?>
    
    <!--Header-->
    <?php include('../template/header.php') ?>

    <!--Connection to Data Base-->
    <?php include('../config/connectionDB.php') ?>

    <!--Views Meetings-->
    <?php include('../config/meetings/viewMeetings.php'); ?>

    <div class="meeting__container">

        <h2 class="meeting__title">Listado de citas<span class="dot">:</span></h2>

        <table class="meeting__table">
            <tr class="table__row--title">
                <th>ID</th>
                <th>Fecha</th>
                <th>Hora</th>
                <th>DNI</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Correo electrónico</th>
                <th>Teléfono</th>
                <th>Administración</th>
            </tr>
            <?php
                if ($result > 0) {
                    while ($meeting = mysqli_fetch_array($consult)) {
            ?>
            <tr class="table__row">
                <td><?php echo $meeting['idMeeting']; ?></td>
                <td><?php
                    $dateMeeting = new DateTime($meeting['dateMeeting']);
                    echo $dateMeeting -> format('d-m-Y');
                ?></td>
                <td><?php echo $meeting['hourMeeting']; ?></td>
                <td><?php echo $meeting['dni']; ?></td>
                <td><?php echo $meeting['name']; ?></td>
                <td><?php echo $meeting['firthSurname']; ?></td>
                <td><?php echo $meeting['email']; ?></td>
                <td><?php echo $meeting['phone']; ?></td>
                <td>
                    <form action="../config/meetings/modMeeting.php" method="post">
                        <input type="text" name="idMeeting" id="idMeeting" value="<?php echo $meeting['idMeeting']; ?>" hidden>
                        <button type="submit" id="btn__select" name="action" value="select">Seleccionar</button>
                        <button type="submit" id="btn__drop" name="action" value="drop">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php            
                    }
                }
            ?>
        </table>

        <!--Add Meeting button-->
        <a href="../config/meetings/addFormMeeting.php" class="btn__add"><i class="fas fa-user-clock"></i> Nueva Cita</a>
    </div>
</body>
</html>