<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administración del Portfolio - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/content/portfolio/portfolio.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!--Session status-->
    <?php include('../config/sessionStatus.php'); ?>
    
    <!--Header-->
    <?php include('../template/header.php'); ?>

    <!--Connection to Database-->
    <?php include('../config/connectionDB.php'); ?>

    <!--Views Portfolio-->
    <?php include('../config/portfolio/viewsPortfolio.php') ?>

    <!--Portfolio container-->
    <div class="portfolio__container">
        <h2 class="portfolio__title">Listado del Portfolio<span class="dot">:</span></h2>

        <!--Portfolio list-->
        <table class="portfolio__table">
            <tr class="table__row--title">
                <th>ID</th>
                <th>Título</th>
                <th>Descripción</th>
                <th>Nombre de la imagen</th>
                <th>Administración</th>
            </tr>
            <?php
                if ($result > 0) {
                    while ($portfolio = mysqli_fetch_array($consult)) {
            ?>
            <tr class="table__row">
                <td id="id"><?php echo $portfolio['idPortfolio']; ?></td>
                <td id="titulo"><?php echo $portfolio['title']; ?></td>
                <td id="descripcion"><?php echo $portfolio['description']; ?></td>
                <td id="imageName"><?php echo $portfolio['imageName']; ?></td>
                <td id="administration">
                    <form action="../config/portfolio/modPortfolio.php" method="POST">
                        <input type="text" name="idPortfolio" id="idPortfolio" value="<?php echo $portfolio['idPortfolio']; ?>" hidden>
                        <button id="btn__select" name="action" value="select">Seleccionar</button>
                        <button id="btn__drop" name="action" value="drop">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php
                    }
                }
            ?>
        </table>

        <!--Add Portfolio button-->
        <a href="../config/portfolio/addFormPortfolio.php" class="btn__add"><i class="fas fa-folder-open"></i> Nueva Especialización</a>
    </div>





    
</body>
</html>