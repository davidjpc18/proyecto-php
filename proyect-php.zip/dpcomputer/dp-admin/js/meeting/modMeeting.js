//Validation Form

const form = document.getElementById('admin');

var validation = "true";

var msg = "";

function validationForm () {

    validationDNI();
    validationDate();

    //Error message container
    const msgContainer = document.getElementById('form__msg');

    //Creation error message
    var msgError = '<span><i class="fas fa-exclamation-triangle"></i> Error:</span>\n' + '<ul>' + msg + '</ul>';

    if (validation == false) {
        msgContainer.classList.add('form__msg--error');
        msgContainer.innerHTML = msgError;
    }else {
        form.submit();
    }
}

//Validation DNI
function validationDNI() {

    var dni = document.getElementById('dni').value;

    //Validation
    valDNI = /^\d{8}[a-zA-Z]$/;
    letterDNI = dni.substring(8,9).toUpperCase();
    numberDNI = parseInt(dni.substring(0,8));
    const letters = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
    var correctLetter = letters[numberDNI % 23];

    if (dni == "") {
        validation = false;
        msg = msg + '<li>El campo "DNI" no puede estar vacío</li>';
    }if (!valDNI.test(dni)) {
        validation = false;
        msg = msg + '<li>El campo "DNI" debe contener 8 números y una letra.</li>'; 
    }if (letterDNI !== correctLetter) {
        validation = false;
        msg = msg + '<li>La letra del campo "DNI" no es correcta.</li>';
    }

}

//Validation Date Meeting
function validationDate() {
    const dateMeet = document.getElementById('dateMeeting').value;
    const hourMeet = document.getElementById('hourMeeting').value;

    //Validation
    var dateMeeting = new Date(dateMeet);
    var monthMeeting = dateMeeting.getMonth();
    var dayMeeting = dateMeeting.getDate();
    var weekMeeting = dateMeeting.getDay();
    const schedule = ['10:00:00', '10:15:00','10:30:00', '10:45:00', '11:00:00', '11:15:00', '11:30:00', '11:45:00', '12:00:00', '12:15:00', '12:30:00', '12:45:00', '13:00:00', '13:15:00', '13:30:00', '13:45:00', '14:00:00', '14:15:00', '14:30:00', '14:45:00', '15:00:00']
    var today = new Date();
    var monthToday = today.getMonth();
    var dayToday = today.getDate();

    //Validation
    if (dateMeeting == "Invalid Date") {
        validation = false;
        msg = msg + '<li>El campo "Fecha" no puede estar vacío o debe poner una fecha válida.</li>';
    }if (monthMeeting == 7) {
        validation = false;
        msg = msg + '<li>No se pueden coger citas en el mes de agosto por estar cerrados por vacaciones.</li>';
    }if (dayToday >= dayMeeting && monthToday >= monthMeeting) {
        validation = false;
        msg = msg + '<li>No podemos darte una cita para esa fecha.</li>';
    }if (weekMeeting == 6 || weekMeeting == 0) {
        validation = false;
        msg = msg + '<li>Nuestro horario laboral es de lunes a viernes.</li>';
    }if (!schedule.includes(hourMeet)) {
        validation = false;
        msg = msg + '<li>Nuestro horario laboral es de 10:00 a 15:00. Y pasamos consulta en intervalos de 15 minutos.</li>';
    }

}