<?php

    session_start();

    if(!isset($_SESSION['usuario'])){
        echo '<script>
            alert("Por favor, es necesario iniciar sesión.");
            window.location = "/dpcomputer/dp-admin/template/login.php";
        </script>';
        session_destroy();
        die();
    }
    
?>