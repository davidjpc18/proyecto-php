<?php

session_start();
session_destroy();

header("Location: /dpcomputer/dp-admin/template/login.php");

?>