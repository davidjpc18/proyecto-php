<?php

$usuario = $_SESSION['usuario'];

$consult = mysqli_query($conn, "SELECT * FROM admin WHERE dni = '$usuario'");

if ($consult) {
    $row = mysqli_fetch_assoc($consult);
    }

?>