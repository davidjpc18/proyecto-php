<?php

    include('connectionDB.php');

    $dni = $_SESSION['usuario'];

    $consult = mysqli_query($conn, "SELECT phone FROM admin WHERE dni ='$dni'");

    if (mysqli_num_rows($consult) > 0){
        $row = mysqli_fetch_assoc($consult);
    }

    //Validation change Phone

    $phone = $row['phone'];
    $changePhone = $_POST['phone'];

    if ($phone !== $changePhone) {
        $sql = mysqli_query($conn, "UPDATE admin SET phone = '$changePhone' WHERE dni = '$dni'");

        echo '<script>
                window.location = "/dpcomputer/dp-admin/content/account.php";
                alert("El número de Teléfono ha sido modificado.");
            </script>';
    }else {
        echo "<script>
                window.location = '/dpcomputer/dp-admin/content/account.php';
                alert('El número de Teléfono no ha sido modificado.');
            </script>";
    }

?>




