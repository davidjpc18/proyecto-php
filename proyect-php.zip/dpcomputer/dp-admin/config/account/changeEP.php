<?php
    
    include('connectionDB.php');

    include('sessionStatus.php');

    $dni = $_SESSION['usuario'];

    $consult = mysqli_query($conn, "SELECT email, password FROM admin WHERE dni = '$dni'");

    if (mysqli_num_rows($consult) > 0){
        $row = mysqli_fetch_assoc($consult);
    }

    //Validation change Email and Password

        //Validation Email

        $email = $row['email'];
        $changeEmail = $_POST['email'];

        if ($email !== $changeEmail){
            $modifyE = 1;
        }else {
            $modifyE = 0;
        }

        //Validation Password

        $password = $row['password'];
        $changePassword = $_POST['password'];
        $changePassword = hash('SHA256', $changePassword);

        if ($password !== $changePassword) {
            $modifyP = 2;
        }else {
            $modifyP = 0;
        }

        $modify = $modifyE + $modifyP;

        if ($modify > 0){
            switch ($modify) {
                case 1:
                    $sql = mysqli_query($conn, "UPDATE admin SET email = '$changeEmail' WHERE dni = '$dni'");
                    echo '<script>
                            window.location = "/dpcomputer/dp-admin/content/account.php";
                            alert("El email ha sido modificado")
                        </script>';
                    break;
                case 2:
                    $sql = mysqli_query($conn, "UPDATE admin SET password = '$changePassword' WHERE dni = '$dni'");
                    echo '<script>
                            window.location = "/dpcomputer/dp-admin/content/account.php";
                            alert("La Contraseña ha sido modificada");
                        </script>';
                    break;
                case 3:
                    $sql = mysqli_query($conn, "UPDATE admin SET email = '$changeEmail' AND password = '$changePassword' WHERE dni = '$dni'");
                    echo '<script>
                            window.location = "/dpcomputer/dp-admin/content/account.php";
                            alert("El email y la Contraseña han sido modificados");
                        </script>';
                    break;
            } 
        }else {
            echo '<script>
                    window.location = "/dpcomputer/dp-admin/content/account.php";
                    alert("No se ha modificado nada");
                </script>';
        }
?>