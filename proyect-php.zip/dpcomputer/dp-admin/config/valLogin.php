<?php
    
    include("connectionDB.php");

    session_start();

    $email = ($_POST['email']);

    $password = ($_POST['password']);
    $password = hash('SHA256', $password);

    $consult = mysqli_query($conn, "SELECT * FROM admin WHERE email = '$email' AND password = '$password'");

    if (mysqli_num_rows($consult) > 0){
        $row = mysqli_fetch_assoc($consult);
        $_SESSION['usuario'] = $row['dni'];
        header("Location: /dpcomputer/dp-admin/index.php");
        exit();
    }else {
        echo
            "<script>
                window.location = '/dpcomputer/dp-admin/template/login.php';
                alert('Usuario o contraseña son erroneos, por favor verifique los datos introducidos');
            </script>";
        exit();
    }
?>