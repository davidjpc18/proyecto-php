<?php

    //Connection to Data Base
    include('../connectionDB.php');

    $portfolio = $_POST['idPortfolio'];

    $image = $_FILES['image'];
    $name = $_FILES['image']['name'];
    $tmpImage = $image['tmp_name'];
    $date = new DateTime();
    $imageName = $date->getTimestamp()."_".$name;
    $imageLink = "/dpcomputer/img/portfolio/".$imageName;

    if ($tmpImage !== "") {
        move_uploaded_file($tmpImage, "../../../img/portfolio/".$imageName);
    }

    if ($image == "") {
        echo '<script>
                window.location = "modPortfolio.php";
                alert("Debe introducir una imagen");
            </script>';
    }else {
        $sql = mysqli_query($conn, "UPDATE portfolio SET imageName = '$imageName', imageLink = '$imageLink' WHERE idPortfolio = '$portfolio'");
        echo '<script>
                window.location = "../../content/portfolio.php";
                alert("Se han modificado la imagen satisfactoriamente.");
            </script>';
    }





?>