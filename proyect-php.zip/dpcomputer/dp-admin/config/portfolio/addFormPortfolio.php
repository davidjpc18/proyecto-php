<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de usuarios - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/content/portfolio/formPortfolio.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!--Administration User-->
    <div class="form__container">
        <form action="addPortfolio.php" method="POST" id="admin" enctype="multipart/form-data">
            <h3 class="admin__title">Crear especialización<span class="dot">:</span></h3>
            <div class="form__inputs">
                <label class="input__title">Título<span class="dot">:</span></label>
                <textarea name="title" id="title"></textarea>
            </div>
            <div class="form__inputs">
                <label class="input__title">Descripción<span class="dot">:</span></label>
                <textarea name="description" id="description"></textarea>
            </div>
            <div class="form__inputs">
                <label class="input__title">Imagen<span class="dot">:</span></label>
                <input type="file" name="image" id="image">
            </div>
            <div class="form__inputs--btn">
                <button type="submit" id="btn__mod">Añadir</button>
                <button type="reset" id="btn__reset">Resetear</button>
            </div>
            <div id="form__msg" class="form__msg"></div>
        </form>
    </div>

</body>
</html>