<?php 
    //Connection to Data Base
    include('../connectionDB.php'); 

    $portfolio = $_POST['idPortfolio'];

    $title = $_POST['title'];
    $description = $_POST['description'];

    $validation = "";

    if ($title == "") {
        $validation = false;
    }if ($description == "") {
        $validation = false;
    }else {
        $validation = true;
    }

    if ($validation == false) {
        echo '<script>
                window.location = "modPortfolio.php";
                alert("Todos los campos deben estar rellenos");
            </script>';
    }else {
        $sql = mysqli_query($conn, "UPDATE portfolio SET title = '$title', description = '$description' WHERE idPortfolio = '$portfolio'");
        echo '<script>
                window.location = "../../content/portfolio.php";
                alert("Se han modificado todos los datos satisfactoriamente.");
            </script>';
    }


?>