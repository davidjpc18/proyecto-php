<?php

    $consult = mysqli_query($conn, "SELECT * FROM portfolio");

    $result = mysqli_num_rows($consult);

?>