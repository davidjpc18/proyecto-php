<?php
    
        //Connection to Data Base.
        include('../connectionDB.php');

        $dni = $_POST['dni'];
        $name = $_POST['name'];
        $firthSurname = $_POST['firthSurname'];
        $secondSurname = $_POST['secondSurname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $birth = $_POST['birth'];
        $role = $_POST['role'];
        $password = hash('SHA256', $_POST['password']);

        $consult = "INSERT INTO users (dni, name, firthSurname, secondSurname, email, phone, birth, role, password) VALUES ('$dni','$name','$firthSurname','$secondSurname','$email','$phone','$birth','$role','$password')";

        $sql = mysqli_query($conn, $consult);

        if ($sql){
            echo "<script>
                    window.location = '../../content/users.php';
                    alert('Se ha añadido el usuario correctamente');
                </script>";
        }else {
            echo "<script>
                    window.location = 'addFormUser.php';
                    alert('Ups! Algo salió mal');
                </script>";
        }
    ?>