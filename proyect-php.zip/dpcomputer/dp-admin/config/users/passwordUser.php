<?php

    //Connection to Data Base.
    include('../connectionDB.php');

    $user = $_POST['dni'];

    $password = $_POST['password'];
    $changePassword = hash('SHA256', $password);
    $consult = mysqli_query($conn, "SELECT password FROM users WHERE dni = '$user'");

    if ($changePassword !== $consult) {
        $sql = mysqli_query($conn, "UPDATE users SET password = '$changePassword' WHERE dni = '$user'");
        echo '<script>
                window.location = "../../content/users.php";
                alert("Se ha modificado la Contraseña correctamente.");
            </script>';
    }else {
        echo '<script>
                window.location = "../../content/users.php";
                alert("No se ha modificado la Contraseña porque son iguales.");
            </script>';
    }

?>