<?php

    $consult = mysqli_query($conn, "SELECT * FROM users");
    
    $result = mysqli_num_rows($consult);

?>