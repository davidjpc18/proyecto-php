<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de usuarios - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/content/users/formUser.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!--Connection to Data Base-->
    <?php include('../connectionDB.php'); ?>

    <?php

        $user = $_POST['dni'];

        $action = $_POST['action'];
    
        $consult = mysqli_query($conn, "SELECT * FROM users WHERE dni = '$user'");

        $row = mysqli_fetch_assoc($consult);

        if ($action == "drop") {
            $sql = mysqli_query($conn, "DELETE FROM users WHERE dni = '$user'");
            echo '<script>
                        window.location = "../../content/users.php";
                        alert("El usuario se ha borrado correctamente");
                    </script>';
        }

    ?>

    <!--Administration User-->
    <div class="form__container">
        <form method="POST" action="updateUser.php" id="admin">
            <h3 class="admin__title">Modificar usuario<span class="dot">:</span></h3>
            <div class="form__inputs">
                <label class="input__title">DNI<span class="dot">:</span></label>
                <input type="text" name="dni" id="dni" value="<?php echo $row['dni']; ?>" readonly>                
            </div>
            <div class="form__inputs">
                <label class="input__title">Nombres<span class="dot">:</span></label>
                <input type="text" name="name" id="name" value="<?php echo $row['name']; ?>">
            </div>
            <div class="form__inputs">
                <label class="input__title">Primer apellido<span class="dot">:</span></label>
                <input type="text" name="firthSurname" id="firthSurname" value="<?php echo $row['firthSurname']; ?>">
            </div>
            <div class="form__inputs">
                <label class="input__title">Segundo apellido<span class="dot">:</span></label>
                <input type="text" name="secondSurname" id="secondSurname" value="<?php echo $row['secondSurname']; ?>">
            </div>
            <div class="form__inputs">
                <label class="input__title">Fecha de nacimiento<span class="dot">:</span></label>
                <input type="date" name="birth" id="birth" value="<?php echo $row['birth']; ?>">
            </div>
            <div class="form__inputs">
                <label class="input__title">Correo electrónico<span class="dot">:</span></label>
                <input type="text" name="email" id="email" value="<?php echo $row['email']; ?>">
            </div>
            <div class="form__inputs">
                <label class="input__title">Teléfono<span class="dot">:</span></label>
                <input type="text" name="phone" id="phone" value="<?php echo $row['phone']; ?>">
            </div>
            <div class="form__inputs">
                <label class="input__title">Privilegios<span class="dot">:</span></label>
                <select name="role" id="role" value="<?php echo $row['role']; ?>">
                    <option value="cliente">Cliente</option>
                    <option value="colaborador">Colaborador</option>
                </select>
            </div>
            <div class="form__inputs--btn">
                <button type="button" id="btn__password" onclick="viewFormPassword()"><i class="fas fa-key"></i> Cambiar contraseña</button>
                <button type="button" id="btn__mod" onclick="validationForm()">Modificar</button>
                <button type="reset" id="btn__reset">Resetear</button>
            </div>
            <div id="form__msg" class="form__msg"></div>
        </form>

        <!--Change Password Form-->
        <div id="password__container" class="password__container">
            <form action="passwordUser.php" method="POST" id="form__password">
                <input type="hidden" name="dni" value="<?php echo $user; ?>">    
                <h3 class="admin__title">Cambiar contraseña<span class="dot">:</span></h3>
                <div class="form__inputs">
                    <label class="input__title">Contraseña<span class="dot">:</span></label>
                    <input type="password" name="password" id="password">
                </div>
                <div class="form__inputs">
                    <label class="input__title">Confirmar contraseña<span class="dot">:</span></label>
                    <input type="password" name="confirmPassword" id="confirmPassword">
                </div>
                <div class="form__inputs--btn">
                    <button type="button" id="btn__mod--password" onclick="validationPassword()">Cambiar contraseña</button>
                    <button type="reset" id="btn__reset--password">Resetear</button>
                </div>
                <div id="form__msg--password" class="form__msg"></div>
            </form>
        </div>
    </div>
    
    <!--JavaScript-->
    <script src="../../js/users/modUser.js"></script>
</body>
</html>