<!--Connection to Data Base-->
<?php 
    //Connection to Data Base
    include('../connectionDB.php'); 

    $user = $_POST['dni'];

    //Email
    $validationEmail = true;

    $changeEmail = $_POST['email'];
    $consultEmailUser = mysqli_query($conn, "SELECT email FROM users WHERE dni = '$user'");
    $consultEmailOtherUser = mysqli_query($conn, "SELECT email FROM users WHERE email = '$changeEmail'");
    $rowEmailOtherUser = mysqli_num_rows($consultEmailOtherUser);
                
    if ($changeEmail == $consultEmailUser) {
        $validationEmail = false;
    }if ($rowEmailOtherUser > 0) {
        $validationEmail = false;
    }else {
        $validationEmail = true;
    }

    if ($validationEmail == false) {
        $sql = mysqli_query($conn, "UPDATE users SET name = '$_POST[name]', firthSurname = '$_POST[firthSurname]', secondSurname = '$_POST[secondSurname]', birth = '$_POST[birth]', phone = '$_POST[phone]', role = '$_POST[role]' WHERE dni = '$user'");
        echo '<script>
                window.location = "../../content/users.php";
                alert("Se han modificado todos los datos, excepto el Correo electrónico");
            </script>';
    }else {
        $sql = mysqli_query($conn, "UPDATE users SET name = '$_POST[name]', firthSurname = '$_POST[firthSurname]', secondSurname = '$_POST[secondSurname]', birth = '$_POST[birth]', email = '$_POST[email]', phone = '$_POST[phone]', role = '$_POST[role]' WHERE dni = '$user'");
        echo '<script>
                window.location = "../../content/users.php";
                alert("Se han modificado todos los datos satisfactoriamente.");
            </script>';
    }

?>