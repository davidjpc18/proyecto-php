<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area de usuarios - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/content/users/formUser.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!--Administration User-->
    <div class="form__container">
        <form action="addUser.php" method="POST" id="admin">
            <h3 class="admin__title">Crear cuenta de usuario<span class="dot">:</span></h3>
            <div class="form__inputs">
                <label class="input__title">DNI<span class="dot">:</span></label>
                <input type="text" name="dni" id="dni">                
            </div>
            <div class="form__inputs">
                <label class="input__title">Nombres<span class="dot">:</span></label>
                <input type="text" name="name" id="name">
            </div>
            <div class="form__inputs">
                <label class="input__title">Primer apellido<span class="dot">:</span></label>
                <input type="text" name="firthSurname" id="firthSurname">
            </div>
            <div class="form__inputs">
                <label class="input__title">Segundo apellido<span class="dot">:</span></label>
                <input type="text" name="secondSurname" id="secondSurname">
            </div>
            <div class="form__inputs">
                <label class="input__title">Fecha de nacimiento<span class="dot">:</span></label>
                <input type="date" name="birth" id="birth">
            </div>
            <div class="form__inputs">
                <label class="input__title">Correo electrónico<span class="dot">:</span></label>
                <input type="text" name="email" id="email">
            </div>
            <div class="form__inputs">
                <label class="input__title">Teléfono<span class="dot">:</span></label>
                <input type="text" name="phone" id="phone">
            </div>
            <div class="form__inputs">
                <label class="input__title">Privilegios<span class="dot">:</span></label>
                <select name="role" id="role">
                    <option value="cliente">Cliente</option>
                    <option value="colaborador">Colaborador</option>
                </select>
            </div>
            <div class="form__inputs">
                <label class="input__title">Contraseña<span class="dot">:</span></label>
                <input type="password" name="password" id="password">
            </div>
            <div class="form__inputs">
                <label class="input__title">Confirmar contraseña<span class="dot">:</span></label>
                <input type="password" name="confirmPassword" id="confirmPassword">
            </div>
            <div class="form__inputs--btn">
                <button type="button" id="btn__mod" onclick="validationForm()">Añadir</button>
                <button type="reset" id="btn__reset">Resetear</button>
            </div>
            <div id="form__msg" class="form__msg"></div>
        </form>
    </div>
    
    <!--JavaScript-->
    <script src="../../js/users/addUser.js"></script>
    
</body>
</html>