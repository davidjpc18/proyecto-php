<?php

    //Connection to Data Base
    include('../connectionDB.php');

    $user = $_POST['dni'];
    $date = $_POST['dateMeeting'];
    $hour = $_POST['hourMeeting'];
    
    $consultMeeting = mysqli_query($conn, "SELECT * FROM meetings WHERE dni = '$user'");

    $rowMeeting = mysqli_num_rows($consultMeeting);

    if ($rowMeeting > 0) {
        $meeting = mysqli_fetch_assoc($consultMeeting);
    }
    
    $cmpDate = strcmp($date, $meeting['dateMeeting']);

    $cmpHour = strcmp($hour, $meeting['hourMeeting']);

    if ($cmpDate == 0 && $cmpHour == 0){
        echo '<script>
                window.location = "../../content/meetings.php";
                alert("No pueden coincidir la misma fecha y hora");
            </script>';
    }else {
        $sql = mysqli_query($conn, "UPDATE meetings SET dateMeeting = '$date', hourMeeting = '$hour' WHERE dni = '$user'");
        echo '<script>
                window.location = "../../content/meetings.php";
                alert("Se han modificado la cita satisfactoriamente.");
            </script>';
    }

?>