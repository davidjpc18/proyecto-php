<?php

    //Connection to Data Base.
    include('../connectionDB.php');

    $date = $_POST['dateMeeting'];
    $hour = $_POST['hourMeeting'];

    $user = $_POST['dni'];

    $consulUser = mysqli_query($conn, "SELECT * FROM users WHERE dni = '$user'");
    $result = mysqli_num_rows($consulUser);

    $validation = "";

    if ($result == 0) {
        $validation = false;
    }else {
        $validation = true;
    }

    if ($validation == true) {

        $consult = "INSERT INTO meetings (dateMeeting, hourMeeting, dni) VALUES ('$date','$hour', '$user')";
        $sql = mysqli_query($conn, $consult);

        if ($sql){
            echo "<script>
                    window.location = '../../content/meetings.php';
                    alert('Se ha añadido la cita correctamente');
                </script>";
        }else {
            echo "<script>
                    window.location = 'addFormMeeting.php';
                    alert('Ups! Algo salió mal');
                </script>";
        }
    }else {
        echo "<script>
                window.location = 'addFormMeeting.php';
                alert('El DNI que ha introducido no corresponde con ningún usuario');
            </script>";
    }
    


?>