<?php

    //Connection to Data Base
    include('../connectionDB.php');

    $new = $_POST['idNew'];

    $image = $_FILES['image'];
    $name = $_FILES['image']['name'];
    $tmpImage = $image['tmp_name'];
    $date = new DateTime();
    $imageName = $date->getTimestamp()."_".$name;
    $imageLink = "/dpcomputer/img/new/".$imageName;

    $consult = mysqli_query($conn, "SELECT imageName FROM news WHERE idNew = '$new'");
    if (mysqli_num_rows($consult) > 0) {
        $row = mysqli_fetch_assoc($consult);
    }

    if ($tmpImage !== "") {
        move_uploaded_file($tmpImage, "../../../img/new/".$imageName);
        unlink("../../../img/new/".$row['imageName']);
    }

    if ($image == "") {
        echo '<script>
                window.location = "modNew.php";
                alert("Debe introducir una imagen");
            </script>';
    }else {
        $sql = mysqli_query($conn, "UPDATE news SET imageName = '$imageName', imageLink = '$imageLink' WHERE idNew = '$new'");
        echo '<script>
                window.location = "../../content/news.php";
                alert("Se ha modificado la imagen satisfactoriamente.");
            </script>';
    }





?>