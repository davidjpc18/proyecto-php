<?php

    $consult = mysqli_query($conn, "SELECT * FROM news ORDER BY idNew DESC");

    $result = mysqli_num_rows($consult);

?>