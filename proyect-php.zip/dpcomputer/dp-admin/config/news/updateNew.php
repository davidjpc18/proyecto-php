<?php

    //Connection to Data Base
    include('../connectionDB.php'); 

    $new = $_POST['idNew'];

    $title = $_POST['title'];
    $description = $_POST['description'];

    $validation = "";

    if ($title == "") {
        $validation = false;
    }if ($description == "") {
        $validation = false;
    }else {
        $validation = true;
    }

    if ($validation == false) {
        echo '<script>
                window.location = "modNew.php";
                alert("Todos los campos deben estar rellenos");
            </script>';
    }else {
        $sql = mysqli_query($conn, "UPDATE news SET title = '$title', description = '$description' WHERE idNew = '$new'");
        echo '<script>
                window.location = "../../content/news.php";
                alert("Se han modificado todos los datos satisfactoriamente.");
            </script>';
    }


?>

