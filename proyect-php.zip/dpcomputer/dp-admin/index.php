<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area administrativa - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/index.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Session status-->
    <?php include('./config/sessionStatus.php') ?>

    <!--Header-->
    <?php include('./template/header.php') ?>

    <!--Button area-->
    <div class="btn__container">
        <a href="/dpcomputer/dp-admin/content/account.php" class="btn">
            <span class="btn__icon"><i class="fas fa-user-alt"></i></span>
            <span class="btn__title">Mi cuenta</span>        
        </a>
        <a href="/dpcomputer/dp-admin/content/portfolio.php" class="btn">
            <span class="btn__icon"><i class="fas fa-book-open"></i></span>
            <span class="btn__title">Portfolio</span>
        </a>
        <a href="/dpcomputer/dp-admin/content/news.php" class="btn">
            <span class="btn__icon"><i class="fas fa-newspaper"></i></span>
            <span class="btn__title">Noticias</span>
        </a>
        <a href="/dpcomputer/dp-admin/content/users.php" class="btn">
            <span class="btn__icon"><i class="fas fa-users"></i></span>
            <span class="btn__title">Usuarios</span>
        </a>
        <a href="/dpcomputer/dp-admin/content/meetings.php" class="btn">
            <span class="btn__icon"><i class="fas fa-calendar-alt"></i></span>
            <span class="btn__title">Citas</span>
        </a>
    </div>
    
</body>
</html>