<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/template/login.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">

    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    
    <!--Form Login-->
    <div class="login__container">
        <form action="/dpcomputer/dp-admin/config/valLogin.php" id="form" method="post">
            <h3 class="form__title--main">Iniciar sesión</h3>
            <div class="form__inputs">
                <label class="form__title">Usuario<span class="dot">:</span></label>
                <input type="text" name="email" id="usuario" placeholder="Introduce tu correo electrónico.">
            </div>
            <div class="form__inputs">
                <label class="form__title">Contraseña<span class="dot">:</span></label>
                <input type="password" name="password" id="password" placeholder="Introduce tu contraseña.">
            </div>
            <div class="form__input-boton">
                <button type="submit" name="btnLogin" id="boton__enviar">Login</button>
            </div>
        </form>
    </div>
</body>
</html>