<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>header</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/dp-admin/css/template/header.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="header__logo">
            <a href="/dpcomputer/dp-admin/index.php" class="header__logo__name--link"><img src="/dpcomputer/img/logo.png" alt="Logo de DP Computer" class="header__logo__img"></a>
        </div>
        <nav class="header__links">
            <a href="/dpcomputer/dp-admin/index.php" class="link">Inicio</a>
            <a href="/dpcomputer/dp-admin/content/account.php" class="link">Area personal</a>
            <a href="/dpcomputer/dp-admin/content/portfolio.php" class="link">Portfolio</a>
            <a href="/dpcomputer/dp-admin/content/news.php" class="link">Noticias</a>
            <a href="/dpcomputer/dp-admin/content/users.php" class="link">Usuarios</a>
            <a href="/dpcomputer/dp-admin/content/meetings.php" class="link">Citas</a>
        </nav>
        <div class="header__user">
            <a href="/dpcomputer/dp-admin/config/closeSession.php" class="link__user"><i class="fas fa-power-off link__user--icon"></i> Cerrar sesión</a>
        </div>
    </header>

    <!--JavaScript-->
    <script>
        
        /*Sticky bar*/

        var nav = document.getElementsByClassName("header");

        window.onscroll = function sticky() {
	        if(window.pageYOffset > nav[0].offsetTop){
		        nav[0].classList.add("header__sticky");
	        }else{
		        nav[0].classList.remove("header__sticky");
	        }
        }
        
    </script>
</body>
</html>