<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DP Computer - La tecnología, más cerca de ti.</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/public/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/public/css/index.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Header area-->
    <?php include("./public/template/header.php") ?>

    <!--Connection to Database-->
    <?php include('./public/config/connectionDB.php'); ?>

    <!--Header cover area-->
    <section class="cover">
        <div class="cover__text">
            <h2 class="cover__title">DP COMPUTER<span class="dot">.</span></h2>
            <p class="cover__copy">La tecnología, <span class="cover__copy--active">más cerca de ti.</span></p>
            <a href="/dpcomputer/public/contacto.php" class="cover__button">Contáctenos</a>
        </div>
        <div class="cover__picture">
            <img src="/dpcomputer/img/logo.png" alt="Logo de DP Computer" class="cover__img" loading="lazy">
        </div>
    </section>

    <!--News area-->
    <section class="news__area">
            <h3 class="news__main__title">Noticias tecnológicas<span class="dot">:</span></h3>
            <div class="new__container">
                <?php
            
                    $consult = mysqli_query($conn, "SELECT * FROM news ORDER BY idNew DESC LIMIT 5");

                    $result = mysqli_num_rows($consult);

                    if($result > 0) {
                        while ($new = mysqli_fetch_array($consult)){
        
                ?>
                    <div class="new">
                        <img src="<?php echo $new['imageLink']; ?>" class="new__img">
                        <div class="new__text">
                            <h3 class="new__title"><?php echo $new['title']; ?></h3>
                            <p class="new__copy"><?php echo substr($new['description'], 0, 250)."..." ?></p>
                        </div>
                    </div>
                <?php
                        }
                    }
                ?>
            </div>
    </section>

    <!--Body area-->
    <main class="body__container">

        <!--Main container-->
        <section class="main">

            <!--Service area-->
            <div class="service">
                <h2 class="service__title">Nuestros servicios<span class="dot">.</span></h2>
                <p class="service__copy">Ofrecemos una solución perfecta según tus necesidades.</p>
                <a href="./public/portfolio.php" class="service__button">Visita nuestro portfolio</a>
            </div>


            <!--Budget area-->
            <div class="budget">
                <h2 class="budget__title">Somos tu mejor opción para adoptar la transformación digital<span class="dot">.</span></h2>
                <p class="budget__copy">Nos comprometemos a proporcionarte un presupuesto a medida y específico para tus necesidades. Además, te lo enviaremos en un plazo de 24 a 48 horas laborables.</p>
                <a href="/dpcomputer/public/presupuesto.php" class="budget__button">Pide tu presupuesto hoy mismo</a>
            </div>
        </section>

    </main>
    <!--Footer area-->
    <?php include("./public/template/footer.php")?>

</body>
</html>