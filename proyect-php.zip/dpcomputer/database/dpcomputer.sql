-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-11-2021 a las 13:07:37
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dpcomputer`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admin`
--

CREATE TABLE `admin` (
  `dni` varchar(9) COLLATE utf8_spanish_ci NOT NULL,
  `name` varchar(35) COLLATE utf8_spanish_ci NOT NULL,
  `firthSurname` varchar(35) COLLATE utf8_spanish_ci NOT NULL,
  `secondSurname` varchar(35) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `phone` int(9) NOT NULL,
  `birth` date NOT NULL,
  `password` varchar(1000) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `admin`
--

INSERT INTO `admin` (`dni`, `name`, `firthSurname`, `secondSurname`, `email`, `phone`, `birth`, `password`) VALUES
('25738079K', 'David José', 'Pacheco', 'Campos', 'davidjpc18@gmail.com', 650834504, '1999-06-16', '068ea3bc6f11936c0609817f4a9558dad12cc4145abe46457cf523db8a75f870');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `meetings`
--

CREATE TABLE `meetings` (
  `idMeeting` int(11) NOT NULL,
  `dateMeeting` date NOT NULL,
  `hourMeeting` time NOT NULL,
  `dni` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `news`
--

CREATE TABLE `news` (
  `idNew` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `imageName` varchar(35) NOT NULL,
  `imageLink` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `news`
--

INSERT INTO `news` (`idNew`, `title`, `description`, `imageName`, `imageLink`) VALUES
(1, 'Telegram crece 70 millones de usuarios tras la caída de Facebook y WhatsApp.', 'Telegram ha sido la gran beneficiada del apagón de Facebook y WhatsApp que se produjo el pasado 4 de octubre durante más de cinco horas que obligó a buscar nuevas vías de comunicación para salvar ese momento crítico.', '1633516582_telegram.png', '/dpcomputer/img/new/1633516582_telegram.png'),
(2, 'El nuevo widget de Google Maps ya está disponible en Android.', 'Una de las aplicaciones de Google que es imprescindible para muchos de nosotros, entre los cuales me incluyo, es Google Maps, una app de mapas y navegación que nos permite llegar a tiempo a nuestras citas personales y laborales y que cada vez se parece más a una red social.\n\nTan solo unos días después de presentar 6 nuevas funciones para respetar el medio ambiente, varias de las cuales se van a incluir en Google Maps a partir del año que viene como las rutas ecológicas o la posibilidad de encontrar bicicletas y motos eléctricas compartidas en más de 300 cuidades de todo el mundo, hoy acabamos de conocer que el nuevo widget de Google Maps ya está disponible en Android.', '1634124380_WidgetMaps.webp', '/dpcomputer/img/new/1634124380_WidgetMaps.webp'),
(3, 'La revolución para cambiar la norma del fuera de juego.', 'Arsène Wenger soltó la bomba, la misma semana en la que la regla está más en entredicho. El exentrenador y actual director de desarrollo del fútbol en la FIFA anunció que el máximo organismo del deporte del balompié quiere \"automatizar\" el fuera de juego para el año 2022.\r\nUna revolución que podría cambiar el deporte, sobre todo en acciones, por ejemplo, como la que tanto se discutió en la final de la UEFA Nations League y que acabó en gol de Mbappé.\r\n\"Hay muchas posibilidades de que el fuera de juego se automatice en 2022. Estoy obligado a mantenerlo en secreto, pero será la próxima de las grandes evoluciones del arbitraje\", decía Wenger durante una charla con la prensa que dio en París.\r\nAsí, una infracción de estas características se sancionaría automáticamente, sin pasar por los árbitros asistentes o la sala VAR, y se podrían minimizar las polémicas en este aspecto. Un planteamiento que ya hace un tiempo que está en la cabeza de los máximos dirigentes de la FIFA, y que parece que avanza ahora en velocidad de crucero.', '1634124931_VAR.jpg', '/dpcomputer/img/new/1634124931_VAR.jpg'),
(4, 'Microsoft anuncia la fecha de lanzamiento de Visual Studio 2022: se podrá descargar el 8 de noviembr', 'Fue en primavera cuando Microsoft anunció Visual Studio 2022. Una aplicación que por entonces anunciaron, debería llegar a lo largo del verano en forma de prueba optando por dar el salto a los 64 bits, como ya ha hecho Microsoft con otras aplicaciones. Y unos meses más tardes, Visual Studio ya tiene fecha concreta de salida.\r\n\r\nMicrosoft ha anunciado que Visual Studio 2022 se lanzará el 8 de noviembre. Una herramienta que permite a los desarrolladores crear aplicaciones web o servicios web en cualquier entorno que soporte la plataforma .NET. Una herramienta disponible para sistemas operativos Windows, Linux y macOS.', '1634125095_VS.jpg', '/dpcomputer/img/new/1634125095_VS.jpg'),
(5, 'Google Discover no funciona: el servicio de la compañía está caído.', 'Google Discover no funciona, el popular servicio de la compañía estadounidense que se encuentra en la parte izquierda de muchos móviles Android se encuentra caído ahora mismo, y es incapaz de mostrar ningún tipo de contenido.\r\nEn este apartado se suelen mostrar resultados deportivos, datos relevantes y noticias que pueden ser de tu interés, y ahora mismo únicamente aparece un mensaje que notifica el servicio está experimentando un error.', '1634125257_GDiscover.jpg', '/dpcomputer/img/new/1634125257_GDiscover.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `portfolio`
--

CREATE TABLE `portfolio` (
  `idPortfolio` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(250) NOT NULL,
  `imageName` varchar(35) NOT NULL,
  `imageLink` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `portfolio`
--

INSERT INTO `portfolio` (`idPortfolio`, `title`, `description`, `imageName`, `imageLink`) VALUES
(1, 'Montaje y mantenimiento de equipos informáticos.', 'Tenemos amplia experiencia a la hora de realizar presupuestos a medida. Además, te asesoraremos sobre cuales son los componentes y periféricos que se adaptan mejor a tus necesidades.', 'hardware.jpg', '/dpcomputer/img/portfolio/hardware.jpg'),
(2, 'Aplicaciones ofimáticas.', 'Manejamos las principales suits de ofimática, como LibreOffice, Microsoft Office, la suit de Google,...etc. También, impartimos cursos para la especialización en estas aplicaciones ofimáticas, tanto a nivel empresarial como doméstico.', 'ofimatica.png', '/dpcomputer/img/portfolio/ofimatica.png'),
(3, 'Seguridad informática', 'Protegemos tu información de posibles ataques o estafas informáticas. Te protegemos a nivel interno como externo. Y te asesoramos a como protegerte a tí mismo.', 'seguridad.jpg', '/dpcomputer/img/portfolio/seguridad.jpg'),
(4, 'Instalaciones de redes cableadas e inalámbricas', 'Especialistas en instalaciones de red (cableada e inalámbricas) y la administración de sus componentes, tanto en un entorno empresarial como doméstico.', 'redes.jpg', '/dpcomputer/img/portfolio/redes.jpg'),
(5, 'Mantenimiento de servidores', 'Instalamos, configuramos y mantenemos servidores para tu empresa, sea en un Hosting o instalado en tu propia empresa. Nos especializamos en los servidores WEB, de intercambio de archivos, de correo,...etc.', 'servidores.jpg', '/dpcomputer/img/portfolio/servidores.jpg'),
(6, 'Desarrollo de página WEB', 'Desarrollamos tu página web según tus necesidades. Ofrecemos diseños atractivos y actuales para que tu página web sea agradable a la vista del usuario. Y posicionamos tu página Web entre las primeras, mediante SEO.', 'web.jpg', '/dpcomputer/img/portfolio/web.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `dni` varchar(9) NOT NULL,
  `name` varchar(35) NOT NULL,
  `firthSurname` varchar(35) NOT NULL,
  `secondSurname` varchar(35) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(9) NOT NULL,
  `birth` date NOT NULL,
  `role` set('client','partner') NOT NULL DEFAULT 'client',
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`dni`, `name`, `firthSurname`, `secondSurname`, `email`, `phone`, `birth`, `role`, `password`) VALUES
('25738079K', 'David José', 'Pacheco', 'Campos', 'davidjpc18@gmail.com', 650834504, '1999-06-16', 'client', '068ea3bc6f11936c0609817f4a9558dad12cc4145abe46457cf523db8a75f870');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`dni`);

--
-- Indices de la tabla `meetings`
--
ALTER TABLE `meetings`
  ADD PRIMARY KEY (`idMeeting`),
  ADD KEY `dni` (`dni`);

--
-- Indices de la tabla `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`idNew`);

--
-- Indices de la tabla `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`idPortfolio`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`dni`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `meetings`
--
ALTER TABLE `meetings`
  MODIFY `idMeeting` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `news`
--
ALTER TABLE `news`
  MODIFY `idNew` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `idPortfolio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `meetings`
--
ALTER TABLE `meetings`
  ADD CONSTRAINT `meetings_ibfk_1` FOREIGN KEY (`dni`) REFERENCES `users` (`dni`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
