<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio - DP Computer</title>

    <!--Hoja de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/public/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/public/css/portfolio.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Header area-->
    <?php include("./template/header.php")?>

    <!--Connection to Database-->
    <?php include('./config/connectionDB.php'); ?>

    <!--Service area-->
    <section class="service">
        <h2 class="service__title">Nuestros servicios<span class="dot">:</span></h2>
        <p class="service__copy">Ofrecemos una solución perfecta según tus necesidades.</p>
    </section>

    <!--Portfolio area-->
    <div class="portfolio__container">
        <?php
            $consult = mysqli_query($conn, "SELECT * FROM portfolio");

            if (mysqli_num_rows($consult) > 0) {
                while ($portfolio = mysqli_fetch_assoc($consult)){
        ?>
            <div class="card">
                <img src="<?php echo $portfolio['imageLink']; ?>" class="card__img">
                <div class="card__text">
                    <h3 class="card__title"><?php echo $portfolio['title']; ?></h3>
                    <p class="card__copy"><?php echo $portfolio['description']; ?></p>
                </div>
            </div>
        <?php
                }
            }
        ?>
    </div>

    <!--Budget area-->
    <section class="budget">
        <h2 class="budget__title">Somos tu mejor opción para adoptar la transformación digital<span class="dot">.</span></h2>
        <p class="budget__copy">Nos comprometemos a proporcionarte un presupuesto a medida y específico para tus necesidades. Además, te lo enviaremos en un plazo de 24 a 48 horas laborables.</p>
        <a href="/dpcomputer/public/presupuesto.php" class="budget__button">Pide tu presupuesto hoy mismo</a>
    </section>

    <!--Footer area-->
    <?php include("./template/footer.php")?>
    
</body>
</html>