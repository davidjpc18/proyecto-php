<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacto - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/public/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/public/css/contacto.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Header area-->
    <?php include("/xampp/htdocs/dpcomputer/public/template/header.php") ?>

    <!--Contac area-->
    <div class="contact">
        <h2 class="contact__title"><span class="dot">¿</span>Cómo puedes contactar con nosotros<span class="dot">?</span></h2>
        <p class="contact__copy">Puedes contactarnos libremente mediante los métodos que te proporcionamos a continuación:</p>
        <div class="contact__container">
            <div class="contact__element">
                <ul class="contact__list">
                    <li><i class="fas fa-phone-alt contact__icon"></i> +34 - 650834504</li>
                    <li><i class="fas fa-envelope contact__icon"></i> davidjpc18@gmail.com</li>
                    <li><i class="fas fa-user-friends contact__icon"></i> Siguenos en nuestras redes sociales: <br>
                        <a href="https://www.instagram.com/davidjospachecocam/" class="contact__social"><i class="fab fa-instagram-square"></i></a>
                        <a href="https://twitter.com/DavidPachecoCam" class="contact__social"><i class="fab fa-twitter-square"></i></a>
                        <a href="https://www.linkedin.com/in/davidpachecocampos/" class="contact__social"><i class="fab fa-linkedin"></i></a>
                        <a href="https://github.com/davidjpc18" class="contact__social"><i class="fab fa-github-square"></i></a>
                    </li>
                    <li><i class="fas fa-map-marked-alt contact__icon"></i> Calle San José 68, 29100 Coín (Málaga)</li>
                </ul>
            </div>
        </div>
    </div>

    <!--Meeting area-->
    <div class="meeting__area">
        <h2 class="meeting__title"><span class="dot">¡</span>Pide tu cita ya<span class="dot">!</span></h2>
        <p class="meeting__copy">Inicia sesión o Registrate para pedir una cita</p>
        <a href="../users/template/login.php" class="meeting__button">Entrar al Area de clientes</a>
    </div>

    <!--Footer area-->
    <?php include("/xampp/htdocs/dpcomputer/public/template/footer.php") ?>

</body>
</html>

