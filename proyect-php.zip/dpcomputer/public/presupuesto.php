<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Presupuesto - DP Computer</title>
    
    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/public/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/public/css/presupuesto.css">
    
    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Header area-->
    <?php include("/xampp/htdocs/dpcomputer/public/template/header.php")?>

    <!--Budget area-->
    <div class="budget">
        <h2 class="budget__title">Solicita tu presupuesto<span class="dot">:</span></h2>
        <p class="budget__copy">Somos tu mejor opción para adoptar la transformación digital.</p>
    </div>

    <!--Form area-->
    <div class="form__area">

        <!--Form budget area-->
        <div class="form__budget__area" id="budget__area">
            <h3 class="form__title--main">Requisitos de la Web</h3>
            <form method="POST" id="form__budget">
                <div class="form__budget__select">
                    <label class="form__title--budget">Tipo de página Web</label>
                    <select name="types" id="types" onchange="presupuesto()">
                        <option value="400">Blog</option>
                        <option value="500">Página web básica</option>
                        <option value="700">Página web con interacción con el usuario</option>
                        <option value="1000">Tienda online</option>
                    </select>
                </div>
                <div class="form__budget__radio">
                    <label class="form__title--budget">Plazos en meses</label>
                    <span class="form__title--budget--copy">(Por cada mes adicional, se hará un 5% de descuento hasta un máximo del 20%)</span>
                    <div>
                        <span class="form__budget__radio--text"><input type="radio" name="month" value="5" class="form__budget__radio--inputs" onchange="presupuesto()"> 1 mes</span>
                        <span class="form__budget__radio--text"><input type="radio" name="month" value="10" class="form__budget__radio--inputs" onchange="presupuesto()"> 2 meses</span>
                        <span class="form__budget__radio--text"><input type="radio" name="month" value="15" class="form__budget__radio--inputs" onchange="presupuesto()"> 3 meses</span>
                        <span class="form__budget__radio--text"><input type="radio" name="month" value="20" class="form__budget__radio--inputs" onchange="presupuesto()"> 4 meses</span>
                        <span class="form__budget__radio--text"><input type="radio" name="month" value="20" class="form__budget__radio--inputs" onchange="presupuesto()"> más de 4 meses</span>
                    </div>
                </div>
                <div class="form__budget__check">
                    <label class="form__title--budget">Marque las opciones deseadas</label>
                    <div class="form__budget__check--inputs">
                        <span class="form__budget__check--input"><input type="checkbox" name="options" value="news" class="options" onchange="presupuesto()"> Noticias</span>
                        <span class="form__budget__check--input"><input type="checkbox" name="options" value="social" class="options" onchange="presupuesto()"> Redes sociales</span>
                        <span class="form__budget__check--input"><input type="checkbox" name="options" value="photos" class="options" onchange="presupuesto()"> Galería de fotos</span>
                        <span class="form__budget__check--input"><input type="checkbox" name="options" value="portfolio" class="options" onchange="presupuesto()"> Portfolio profesional</span>
                        <span class="form__budget__check--input"><input type="checkbox" name="options" value="internal" class="options" onchange="presupuesto()"> Gestión interna</span>
                        <span class="form__budget__check--input"><input type="checkbox" name="options" value="design" class="options" onchange="presupuesto()"> Diseño moderno</span>
                        <span class="form__budget__check--input"><input type="checkbox" name="options" value="seo" class="options" onchange="presupuesto()"> Posicionamiento web</span>   
                    </div>
                </div>
                <div class="form__budget__price">
                    <h4 class="form__title--budget">Presupuesto estimado:</h4>
                    <p class="form__title--budget--copy">(Recuerde que este presupuesto es estimado, dependiendo de la web podría aumentar o disminuir)</p>
                    <div id="budget__price">0€</div>
                </div>
                <div class="form__budget__btn">
                    <button type="button" id="budget__btn" onclick="envioPresupuesto()">Enviar el presupuesto</button>
                </div>
            </form>
        </div>

    </div>
    <!--Footer area-->
    <?php include("/xampp/htdocs/dpcomputer/public/template/footer.php") ?>

    <!--JavaScript-->
    <script src="/dpcomputer/public/js/presupuesto.js"></script>
</body>
</html>