<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>footer</title>
    
    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/public/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/public/css/template/footer.css">
    
    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <div id="footer" class="footer">
        <div class="footer__social">
            <p class="footer__social__title">Síguenos en<span class="dot">:</span></p>
            <div>
                <a href="https://www.instagram.com/davidjospachecocam/" class="footer__social__links"><i class="fab fa-instagram-square"></i></a>
                <a href="https://twitter.com/DavidPachecoCam" class="footer__social__links"><i class="fab fa-twitter-square"></i></a>
                <a href="https://www.linkedin.com/in/davidpachecocampos/" class="footer__social__links"><i class="fab fa-linkedin"></i></a>
                <a href="https://github.com/davidjpc18" class="footer__social__links"><i class="fab fa-github-square"></i></a>
            </div>
        </div>
        <div class="footer__address__area">
            <a href="https://goo.gl/maps/BbKNX9DAmD1EzzDa7" class="footer__address"><i class="fas fa-map-marked-alt footer__address__icon"></i> Calle San José 68, 29100 Coín (Málaga)</a>
        </div>
        <div class="footer__politic__area">
            <a href="/dpcomputer/public/politica.php" class="footer__politic">Política de privacidad <sup><i class="far fa-copyright footer__politic__icon"></i></sup></a>
        </div>
    </div>
</body>
</html>