<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de privacidad - DP Computer</title>

    <!--Hojas de estilos CSS-->
    <link rel="stylesheet" href="/dpcomputer/public/css/main.css">
    <link rel="stylesheet" href="/dpcomputer/public/css/politica.css">

    <!--Font Awesome - Fuente de iconos-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    
    <!--Google Font - Fuentes de letra-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <!--Header area-->
    <?php include("/xampp/htdocs/dpcomputer/public/template/header.php") ?>
    
    <!--Politic area-->
    <div class="politic">
        <h2 class="politic__title">Políticas de privacidad<span class="dot">.</span></h2>
        <ol class="politic__list">
            <li><span class="politic__subtitle">Datos identificativos del titular</span>
                <br>
                <br>
                Los presentes términos y condiciones generales de venta regulan de manera integral todas las transacciones de venta que se puedan ofertar, prestar o realizar desde la tienda on-line ubicada en la página web www.dpcomputer.es de la cual es titular David Pacheco (En adelante DP Computer), con Número o Código de identificación fiscal nº 54243886L, domicilio social en Calle Aguamarina 36, 29100 Coín (Málaga) e inscrita en .
                Estos términos y condiciones pueden ser modificados por DP Computer en cualquier momento, siendo el usuario informado de la existencia de cualquier nueva versión de estas que contenga cambios que resulten sustanciales.
            </li>
            <li><span class="politic__subtitle">El usuario</span>
                <br>
                <br>
                El acceso, la navegación y uso del Sitio Web, confiere la condición de usuario, por lo que se aceptan, desde que se inicia la navegación por el Sitio Web, todas las Condiciones aquí establecidas, así como sus ulteriores modificaciones, sin perjuicio de la aplicación de la correspondiente normativa legal de obligado cumplimiento según el caso.
                El Usuario asume su responsabilidad de un uso correcto del Sitio Web. Esta responsabilidad se extenderá a:
                <br>
                · Hacer uso de este Sitio Web únicamente para realizar consultas y compras o adquisiciones legalmente válidas.
                <br>
                · No realizar ninguna compra falsa o fraudulenta.
                <br>
                · Facilitar datos de contacto veraces y lícitos, por ejemplo, dirección de correo electrónico, dirección postal y/u otros datos.
                <br>
                El Usuario declara ser mayor de 18 años y tener capacidad legal para celebrar contratos a través de este Sitio Web.
                El Sitio Web está dirigido principalmente a Usuarios residentes en España. DP Computer no asegura que el Sitio Web cumpla con legislaciones de otros países, ya sea total o parcialmente.
            </li>
            <li><span class="politic__subtitle">Aplicabilidad de las condiciones generales</span>
                <br>
                <br>
                Estas condiciones se aplican a todas las cotizaciones, ofertas, actividades, acuerdos y entregas de productos por o en nombre de DP Computer. La desviación de estas condiciones sólo es posible si las partes así lo han acordado explícitamente por escrito.
            </li>
            <li><span class="politic__subtitle">Objeto</span>
                <br>
                <br>
                Las presentes condiciones regularán el uso de la web www.dpcomputer.es que DP Computer pone a disposición de sus usuarios y clientes. La compra en www.dpcomputer.es podrá realizarse desde España, comprendiendo todo el territorio español. Los productos que DP Computer vende a través de su página web son, principalmente:
                Servicios informáticos
                Estas Condiciones Generales han sido elaboradas de conformidad con lo establecido en la Ley 34/2002, de servicios de la sociedad de la información y de comercio electrónico, Real Decreto Legislativo 1/2007, de 16 noviembre, por el que se aprueba el texto refundido de la Ley General para la Defensa de los Consumidores y Usuarios y otras leyes complementarias, todas ellas disposiciones legales de obligada aplicación.
                DP Computer podrá modificarlas sin previo aviso, de manera que recomienda una periódica consulta de las mismas, más aún cuando se disponga a hacer un uso efectivo de su tienda online ubicada en la web www.dpcomputer.es. No obstante, DP Computerse compromete siempre a tenerlas actualizadas, a publicar la última versión y permitir su acceso e impresión en cualquier momento.
            </li>
            <li><span class="politic__subtitle">Condiciones de acceso y compra</span>
                <br>
                <br>
                El acceso al Portal de DP Computer es libre y atribuye a quien lo realiza la condición de Usuario, independientemente del posterior uso de los servicios ofrecidos.
                Se permitirá la compra sin necesidad de registro previo, debiendo en cualquier caso cumplimentar el formulario, a los efectos de identificar al comprador y el domicilio de entrega. 
                La adquisición de los productos en www.dpcomputer.es sólo podrá hacerse por usuarios mayores de dieciocho (18) años, que deberán seguir los pasos e instrucciones que acompañarán todo el proceso de compra, consistentes, a modo meramente enunciativo:
                (i) Cumplimentación del formulario de alta o el de identificación de usuarios previamente registrados;
                (ii) Visualización en pantalla del resumen del pedido, condiciones de entrega y gastos – en su caso – de envío;
                (iii) Aceptación de condiciones de compra, lo cual supone la lectura, comprensión y aceptación irrevocable de todas y cada una de las presentes Condiciones Generales, así como en su caso, de las Condiciones Particulares existentes y
                (iv) recepción inmediata de correo electrónico de resumen en la cuenta utilizada en el registro o – en su defecto – en el plazo más breve posible y siempre antes de las veinticuatro horas siguientes.
                No está permitida la adquisición de productos en www.dpcomputer.es para su posterior distribución o reventa, bien sea en establecimientos públicos o bien realizados en el ámbito doméstico. DP Computer regulará y autorizará los permisos necesarios si en algún momento lo consintiese, por lo que notificaría fehacientemente dicha habilitación al agente autorizado.
            </li>
            <li><span class="politic__subtitle">Pedidos</span>
                <br>
                <br>
                No se podrá realizar pedido válido alguno sin aceptar expresamente, a través de las casillas habilitadas a estos efectos, los términos y condiciones y la política de privacidad de DP Computer. 
                Todos los pedidos se consideraran ofertas de compra sometidas a estos términos y condiciones. DP Computer se reserva el derecho de aceptar las mismas si no se cumplen los requisitos previstos en estas.
                Realizado un pedido el sistema genera automáticamente un comprobante de la recepción del mismo. No obstante esta confirmación no supone la aceptación automática del pedido, dado que DP Computer se reserva el derecho a recabar información adicional, relacionada con la identidad y el domicilio para garantizar , tanto un correcto envió del pedido, como para asegurar la inexistencia de fraude relacionado con las transacciones.
                Pueden realizarse pedidos los 365 días del año, a cualquier hora, salvo en los momentos en que el servicio este suspendido por mantenimiento o por otras circunstancias comerciales y/o de fuerza mayor.
                Cualquier pedido está sujeto a la disponibilidad de producto. En caso de que no resulte posible entregar un pedido por problemas en el suministro o por no disponer de stock suficiente, el usuario tendrá la opción de esperar hasta que el producto esté disponible o cancelar el pedido.
            </li>
            <li><span class="politic__subtitle">Entrega</span>
                <br>
                <br>
                Se considerará que se ha producido la entrega en el momento en el que el usuario o un tercero indicado por él adquiera la posesión material de los productos.
                El plazo de entrega para el pedido variará según el método de envío seleccionado y se verá indicado en la página web una vez se obtenga la confirmación del pedido, en cualquier caso no superará los 30 días a contar desde la fecha de la confirmación del pedido. En caso de que no se pueda cumplir con la fecha de entrega, informaremos de esta circunstancia al usuario y se le ofrecerá la opción de seguir adelante con la compra fijando una nueva fecha de entrega o la posibilidad de anular el pedido obteniendo el reembolso total del precio pagado.
                Si el destinatario se encuentra ausente en el momento de la entrega, se dejará un aviso para que pueda recoger el envío en el lugar y en los plazos que se indiquen. Transcurridos el plazo sin que se produzca la recogida, el envío será devuelto a DP Computer.
            </li>
            <li><span class="politic__subtitle">Precio y pago</span>
                <br>
                <br>
                Se entiende que el precio de cada producto es el que aparecerá en la página web en el momento de realizar cada pedido. El usuario deberá abonar el precio marcado, incluyendo los impuestos aplicables, junto con los gastos de envío, que se añadirán al precio final a pagar. 
                Los precios pueden ser modificados por DP Computer en cualquier momento y sin previo aviso sin que ello afecte a los pedidos ya confirmados. No obstante, incluso confirmado DP Computer no estará obligado a atender pedidos cuando el precio sea incorrecto, especialmente, cuando el error sea manifiesto y sea reconocible con facilidad.
                Los medios de pago aceptados son: 
                Pago con tarjeta de crédito o débito. Nos reservamos el derecho de NO aceptar ciertos pagos con determinadas tarjetas de crédito. 
                Pago mediante PayPal. 
                DP Computer se reserva el derecho a cambiar las modalidades de pago, pudiendo crear nuevas o eliminar alguna de las existentes, sin que el usuario/cliente de www.dpcomputer.es pueda realizar reclamaciones por este motivo. No obstante si el cambio en la modalidad de pago afectase a un pedido ya realizado, desde www.dpcomputer.es nos pondríamos en contacto con el cliente para informarle de dicho cambio, ofreciéndole la opción de cancelar el pedido si lo considerase conveniente.
                Pago con tarjeta de crédito/débito: El cargo se realiza online, es decir, en tiempo real, a través de la pasarela de pago de la entidad financiera correspondiente y una vez se haya comprobado que los datos comunicados son correctos. Con el objetivo de dar la máxima seguridad al sistema de pago www.dpcomputer.es utiliza sistemas de pago seguro de entidades financieras de primera línea en comercio electrónico. En este sentido, los datos confidenciales son transmitidos directamente y de forma encriptada (SSL) a la entidad financiera correspondiente. El sistema de encriptación SSL que se utiliza confiere total seguridad a la transmisión de datos a través de la red. Los datos del cliente gozan de total confidencialidad y protección. Los datos sobre las tarjetas de crédito no quedan registrados en ninguna base de datos nuestra. Están únicamente utilizados en el TPV (Terminal Punto de Venta) virtual de la entidad financiera de DP Computer, a través de su Pasarela de Pago Seguro. Las tarjetas de crédito estarán sujetas a comprobaciones y autorizaciones por parte de la entidad emisora de las mismas, pero si dicha entidad no autorizase el pago, DP Computer no se hace responsable por ningún retraso o falta de entrega y no podrá formalizar ningún Contrato con el cliente. DP Computer se reserva el derecho de verificar los datos personales suministrados por el cliente y adoptar las medidas que estime oportunas (incluida la cancelación del pedido) para que la mercancía adquirida sea entregada de conformidad con los datos que figuran en el pedido. 
                Los pagos con PayPal se realizan directamente en la web de PayPal, siguiendo las condiciones de uso que establece PayPal. En el caso de no pagar el pedido en el plazo de una hora, DP Computer dará por cancelado el pedido.
            </li>
            <li><span class="politic__subtitle">Derecho de desistimiento</span>
                <br>
                <br>
                El Usuario tiene derecho a desistir del contrato celebrado a través de www.dpcomputer.es en un plazo de 14 días naturales sin necesidad de justificación.
                El plazo de desistimiento expirará a los 14 días naturales del día en que el Usuario o un tercero por él indicado, distinto del transportista, haya adquirido la posesión material de los bienes.
                Para ejercer el derecho de desistimiento, el Usuario deberá notificar a DP Computer su decisión de desistir del contrato a través de una declaración inequívoca (por ejemplo, una carta enviada por correo postal, fax o correo electrónico). El Usuario podrá utilizar el modelo de formulario de desistimiento que se incluye al final de estas condiciones, aunque su uso no es obligatorio.
                Para cumplir el plazo de desistimiento, basta con que la comunicación relativa al ejercicio por parte del Usuario de este derecho sea enviada antes de que venza el plazo correspondiente.
                En caso de desistimiento, DP Computer devolverá todos los pagos recibidos del Usuario, incluidos los gastos de entrega (con la excepción de los gastos adicionales resultantes de la elección por parte del Usuario de una modalidad de entrega diferente a la modalidad menos costosa de entrega ordinaria que se ofrezca) sin ninguna demora indebida y, en todo caso, a más tardar 14 días naturales a partir de la fecha en la que el Usuario informe a DP Computer de su decisión de desistir del contrato. DP Computer procederá a efectuar dicho reembolso utilizando el mismo medio de pago empleado por el Usuario para la transacción inicial, a no ser que éste haya dispuesto expresamente lo contrario; en todo caso, el Usuario no incurrirá en ningún gasto como consecuencia del reembolso. DP Computer podrá retener el reembolso hasta haber recibido los bienes, o hasta que el Usuario haya presentado una prueba de la devolución de los mismos, según qué condición se cumpla primero.
                El Usuario deberá devolver o entregar directamente los bienes a DP Computer, sin ninguna demora indebida y, en cualquier caso, a más tardar en el plazo de 14 días naturales a partir de la fecha en que nos comunique su decisión de desistimiento del contrato en el domicilio de DP Computer indicado al principio de estas Condiciones. Se considerará cumplido el plazo si el Usuario efectúa la devolución de los bienes antes de que haya concluido dicho plazo. El Usuario deberá asumir el coste directo de devolución de los bienes.
                El Usuario sólo será responsable de la disminución de valor de los bienes resultante de una manipulación distinta a la necesaria para establecer la naturaleza, las características y el funcionamiento de los bienes.
                Se especifica en el presente documento que cualesquiera Productos no sellados tras su entrega o que puedan ser objeto de devolución por motivos sanitarios o fines de protección de la salud, no serán susceptibles de desistimiento (incluyendo, a título no limitativo, cualesquiera Productos de cuidado de la belleza si se retira su tapa o cierre). 
                El derecho de desistimiento no será aplicable a los contratos que se refieran a:
                <br>
                · El suministro de bienes cuyo precio dependa de fluctuaciones del mercado financiero que DP Computer no pueda controlar
                <br>
                · El suministro de bienes confeccionados conforme a las especificaciones del consumidor y usuario o claramente personalizados.
                <br>
                · El suministro de bienes que puedan deteriorarse o caducar con rapidez.
                <br>
                · El suministro de bienes precintados que no sean aptos para ser devueltos por razones de protección de la salud o de higiene y que hayan sido desprecintados tras la entrega.
                <br>
                · El suministro de bienes que después de su entrega y teniendo en cuenta su naturaleza se hayan mezclado de forma indisociable con otros bienes.
                <br>
                · El suministro de bebidas alcohólicas cuyo precio haya sido acordado en el momento de celebrar el contrato de venta y que no puedan ser entregadas antes de 30 días, y cuyo valor real dependa de fluctuaciones del mercado que el DP Computer no pueda controlar.
                <br>
                · Los contratos en los que el consumidor y usuario haya solicitado específicamente a DP Computer que le visite para efectuar operaciones de reparación o mantenimiento urgente.
                <br>
                · El suministro de grabaciones sonoras o de vídeo precintadas o de programas informáticos precintados que hayan sido desprecintados por el consumidor y usuario después de la entrega.
                <br>
                · El suministro de prensa diaria, publicaciones periódicas o revistas, con la excepción de los contratos de suscripción para el suministro de tales publicaciones.
                <br>
                · El suministro de contenido digital que no se preste en un soporte material cuando la ejecución haya comenzado con el previo consentimiento expreso del consumidor y usuario con el conocimiento por su parte de que en consecuencia pierde su derecho de desistimiento.
            </li>
            <li><span class="politic__subtitle">Garatía</span>
                <br>
                <br>
                De acuerdo con la Ley General para la Defensa de los Consumidores y Usuarios y otras leyes complementarias, DP Computer ofrece sobre todos sus productos una garantía de dos (2) años desde su entrega y procederemos, según corresponda, a la reparación, sustitución, rebaja del precio o devolución del importe del producto. Si tiene que realizar una reclamación de garantía le rogamos que se ponga en contacto con nosotros a través de los medios de contacto previstos anteriormente.
                Esta garantía no cubre posibles roturas o desgastes provocados por el uso. El consumidor y usuario deberá informar al vendedor de la falta de conformidad en el plazo de dos meses desde que tuvo conocimiento de ella.
                Garantía comercial
                Los productos vendidos también están cubiertos por una garantía comercial para asegurar su conformidad y para asegurar el reembolso del precio de compra, la sustitución o la reparación de los bienes. No cubre los defectos causados por un uso anormal o inadecuado o por una causa no relacionada con las cualidades intrínsecas de los productos.
            </li>
            <li><span class="politic__subtitle">Servicio de atención al cliente</span>
                <br>
                <br>
                DP Computer dispone de un servicio de atención al cliente para que el Usuario pueda gestionar sus reclamaciones, dudas, o pueda solicitar garantías y ejecutar el derecho de desistimiento.
                El Usuario puede dirigir sus quejas, reclamaciones o solicitudes de información al Servicio de Atención al Cliente de DP Computer, utilizando para ello cualquiera de las siguientes vías:
                <br>
                - Enviando un correo electrónico a davidjpc18@outlook.es
                <br>
                - Llamando al teléfono 952441843  , de lunes a viernes  (9:00 a 18:00)
                <br>
                Todas las dudas y especialmente las quejas y sugerencias serán atendidas a la mayor rapidez, sin sobrepasar en ningún caso los plazos que establezca la legislación vigente.
                Asimismo, tendrá constancia de las mismas mediante la entrega de un justificante por escrito, en papel o en cualquier otro soporte duradero.
            </li>
            <li><span class="politic__subtitle">Protección de datos personales</span>
                <br>
                <br>
                David Pacheco, es el Responsable del tratamiento de los datos personales del Usuario y le informa que estos datos serán tratados de conformidad con lo dispuesto en la Ley Orgánica 3/2018, de 5 de diciembre, de Protección de Datos Personales y garantía de los derechos digitales y el Reglamento (UE) 2016/679 de 27 de abril de 2016 (RGPD) relativo a la protección de las personas físicas en lo que respecta al tratamiento de datos personales y a la libre circulación de estos datos, por lo que se le facilita la siguiente información del tratamiento:
                Fin del tratamiento: 
                Mantener una relación comercial con el Usuario.
                Datos recogidos:
                Los datos personales recogidos en este sitio son los siguientes:
                <br>
                · Apertura de la cuenta: al crear la cuenta del usuario, su nombre, apellidos, número de teléfono, dirección postal, número de tarjeta de crédito o débito
                <br>
                · Login: cuando el usuario se conecta a la página web, registra, en particular, su apellido, nombre, datos de acceso, datos de uso, ubicación y datos de pago.
                <br>
                · Perfil: la utilización de los servicios prestados en el sitio web permite introducir un perfil, que puede incluir una dirección y un número de teléfono.
                <br>
                · Pago: como parte del pago de los productos y servicios ofrecidos en el sitio web, se registran los datos financieros relativos a la cuenta bancaria o tarjeta de crédito del usuario.
                <br>
                · Comunicación: cuando el sitio web se utiliza para comunicarse con otros miembros, los datos relativos a las comunicaciones del usuario se almacenan temporalmente.
                <br>
                · Cookies: Las cookies se utilizan cuando se utiliza el sitio. El usuario tiene la posibilidad de desactivar las cookies desde la configuración de su navegador.
                <br>
                Uso de los datos personales:
                <br>
                La finalidad de los datos personales recogidos de los usuarios es poner a su disposición los servicios del sitio web, mejorarlos y mantener un entorno seguro. Más específicamente, los usos son los siguientes:
                <br>
                · acceso y uso del sitio web por parte del usuario;
                <br>
                · gestión del funcionamiento y optimización de la página web;
                <br>
                · organización de las condiciones de uso de los Servicios de Pago;
                <br>
                · verificación, identificación y autenticación de los datos transmitidos por el usuario;
                <br>
                · propuesta al usuario de la posibilidad de comunicarse con otros usuarios del sitio web;
                <br>
                · implementación de la asistencia al usuario;
                <br>
                · personalización de los servicios mediante la visualización de anuncios en función del historial de navegación del usuario, según sus preferencias;
                <br>
                · prevención y detección de fraudes, gestión de malware (software malicioso) y de incidentes de seguridad;
                <br>
                · gestión de posibles conflictos con los usuarios;
                <br>
                · el envío de información comercial y publicitaria, según las preferencias del usuario.
                <br>
                Compartir datos personales con terceros.
                <br>
                Los datos personales pueden ser compartidos con terceros en los siguientes casos:
                <br>
                · cuando el usuario utiliza los servicios de pago, para la implementación de estos servicios, el sitio web está en contacto con terceras entidades bancarias y financieras con las que ha celebrado contratos;
                <br>
                · cuando el usuario publica información de acceso público en las áreas de comentarios gratuitos del sitio web;
                <br>
                · cuando el usuario autoriza al sitio web de un tercero a acceder a sus datos;
                <br>
                · cuando el sitio web utilice los servicios de los proveedores de servicios para proporcionar servicios de apoyo al usuario, publicidad y pago. Estos proveedores de servicios tienen un acceso limitado a los datos del usuario, en el contexto de la prestación de estos servicios, y tienen la obligación contractual de utilizarlos de conformidad con las disposiciones de la normativa aplicable sobre protección de datos personales;
                <br>
                · si así lo exige la ley, el sitio web puede transmitir datos para presentar reclamaciones contra el sitio web y cumplir con los procedimientos administrativos y judiciales;
                <br>
                Seguridad y confidencialidad.
                <br>
                El sitio web aplica medidas organizativas, técnicas, de software y físicas en materia de seguridad digital para proteger los datos personales contra la alteración, destrucción y acceso no autorizados. Sin embargo, cabe señalar que Internet no es un entorno completamente seguro y que el sitio web no puede garantizar la seguridad de la transmisión o el almacenamiento de la información en Internet.
                <br>
                Implementación de los derechos de los usuarios
                De acuerdo con la normativa aplicable a los datos de carácter personal, los usuarios tienen los siguientes derechos, que pueden ejercitar dirigiendo su solicitud a la siguiente dirección Calle Aguamarina 36, 29100 Coín (Málaga) o al correo electrónico davidjpc18@outlook.es.
                Derecho a retirar el consentimiento en cualquier momento.
                Derecho de acceso, rectificación, portabilidad y supresión de sus datos y a la limitación u oposición a su tratamiento.
                Derecho a presentar una reclamación ante la autoridad de control (agpd.es) si considera que el tratamiento no se ajusta a la normativa vigente.
            </li>
            <li><span class="politic__subtitle">Idioma del contrato</span>
                <br>
                <br>
                Estas condiciones generales de venta están redactadas en castellano. En caso de que se traduzcan a una o varias lenguas extranjeras, prevalecerá el texto en castellano en caso de litigio.
            </li>
            <li><span class="politic__subtitle">Legislación aplicable</span>
                <br>
                <br>
                Estas Condiciones Generales se rigen por la ley española. Las partes se someten, a su elección, para la resolución de los conflictos y con renuncia a cualquier otro fuero, a los juzgados y tribunales del domicilio del usuario.
                Además, se encuentra adherida a:
                DP Computer (dpcomputer.com) 
                Por ello, en caso de controversias relativas a la contratación y publicidad online, protección de datos y protección de menores, el usuario podrá acudir  al sistema de resolución extrajudicial de controversias de la  entidad.
            </li>
        </ol>
    </div>

    <!--Footer area-->
    <?php include("/xampp/htdocs/dpcomputer/public/template/footer.php") ?>
</body>
</html>