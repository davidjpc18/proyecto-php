//Budget area

const formPresupuesto = document.getElementById('form__budget');
var elementos = formPresupuesto.elements;

function presupuesto(){

    //Tipos de páginas web
    var tipos = parseInt(formPresupuesto.types.value);

    //Descuentos aplicados según los meses de plazos
    var porcentaje = formPresupuesto.month.value;

    //Opciones añadidas para la página Web
    var checks = document.querySelectorAll('.options');
    var opciones = 0;

    checks.forEach((e) => {
        if (e.checked == true){
            if (e.value == 'news'){
                opciones = opciones + 400;
               }if (e.value == 'social'){
                opciones = opciones + 400;
               }if (e.value == 'photos'){
                opciones = opciones + 400;
               }if (e.value == 'portfolio'){
                opciones = opciones + 400;
               }if (e.value == 'internal'){
                opciones = opciones + 400;
               }if (e.value == 'design'){
                opciones = opciones + 400;
               }if (e.value == 'seo'){
                opciones = opciones + 400;
               }
        }
    });

    //Sumar los requisitos del cliente para su página web.
    var sumaPrecio = tipos + opciones;

    //Averigua la cantidad que se tiene que descontar por el número de meses de plazos.
    var descontado = sumaPrecio * porcentaje / 100;

    //Precio final con el descuento incluido.
    var totalPresupuesto = sumaPrecio - descontado;

    document.getElementById('budget__price').innerHTML = totalPresupuesto + "€";

}

function envioPresupuesto(){

    if (formPresupuesto.month.value == 0){
        alert('El campo "Meses de plazo" debe estar seleccionado alguna opción.')
    }else {
        alert('Se ha enviado correctamente el presupuesto\n' + 'En un plazo de 24h - 48h nos pondremos en contacto con usted.')
    }
}
